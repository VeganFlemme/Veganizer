// Auth hook - referencing blueprint:javascript_log_in_with_replit
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
}

// Rate limiting state to prevent flooding
const authRequestState = {
  lastRequest: 0,
  retryCount: 0,
  maxRetries: 3,
  baseDelay: 1000, // 1 second
};

export function useAuth() {
  const queryClient = useQueryClient();
  
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ["/api/auth/user"],
    retry: false,
    staleTime: Infinity, // Use default from queryClient to prevent refetching
    gcTime: 10 * 60 * 1000, // 10 minutes
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    refetchInterval: false, // Explicitly disable polling
    refetchIntervalInBackground: false,
    queryFn: async () => {
      const now = Date.now();
      
      // Rate limiting with exponential backoff
      if (authRequestState.retryCount > 0) {
        const timeSinceLastRequest = now - authRequestState.lastRequest;
        const requiredDelay = authRequestState.baseDelay * Math.pow(2, authRequestState.retryCount - 1);
        
        if (timeSinceLastRequest < requiredDelay) {
          // Too soon, return cached null to prevent request
          console.warn(`Auth request rate limited. Next attempt in ${Math.ceil((requiredDelay - timeSinceLastRequest) / 1000)}s`);
          return null;
        }
      }
      
      authRequestState.lastRequest = now;
      
      try {
        const res = await fetch("/api/auth/user", {
          credentials: "include",
        });
        
        // Return null for 401 (not authenticated) instead of throwing
        if (res.status === 401) {
          // Increment retry count for 401s to slow down requests
          authRequestState.retryCount = Math.min(authRequestState.retryCount + 1, authRequestState.maxRetries);
          return null;
        }
        
        if (!res.ok) {
          authRequestState.retryCount = Math.min(authRequestState.retryCount + 1, authRequestState.maxRetries);
          throw new Error(`${res.status}: ${res.statusText}`);
        }
        
        // Success - reset retry count
        authRequestState.retryCount = 0;
        return await res.json();
      } catch (error) {
        authRequestState.retryCount = Math.min(authRequestState.retryCount + 1, authRequestState.maxRetries);
        throw error;
      }
    },
  });

  const logout = async () => {
    try {
      await apiRequest("GET", "/api/logout");
      // Invalidate auth queries to trigger re-fetch
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      // Minimal redirect after OIDC logout flow
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
      // Fallback: clear cache even if request fails
      queryClient.setQueryData(["/api/auth/user"], null);
    }
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    logout,
  };
}