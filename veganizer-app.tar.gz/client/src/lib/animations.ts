/**
 * Premium Animation System for Veganizer
 * Reusable Framer Motion variants and utilities
 */

import { Variants } from 'framer-motion';

// Easing curves for premium feel
export const easings = {
  smooth: [0.25, 0.1, 0.25, 1],
  bounce: [0.68, -0.55, 0.265, 1.55],
  gentle: [0.4, 0, 0.2, 1],
  snappy: [0.25, 0.46, 0.45, 0.94],
} as const;

// Page transition variants
export const pageTransition: Variants = {
  initial: {
    opacity: 0,
    y: 20,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: easings.gentle,
      staggerChildren: 0.1,
    },
  },
  exit: {
    opacity: 0,
    y: -20,
    transition: {
      duration: 0.3,
      ease: easings.gentle,
    },
  },
};

// Card hover animations
export const cardHover: Variants = {
  rest: {
    scale: 1,
    y: 0,
    transition: {
      duration: 0.3,
      ease: easings.gentle,
    },
  },
  hover: {
    scale: 1.02,
    y: -8,
    transition: {
      duration: 0.3,
      ease: easings.gentle,
    },
  },
  tap: {
    scale: 0.98,
    transition: {
      duration: 0.1,
      ease: easings.snappy,
    },
  },
};

// Fade in up animation for sections
export const fadeInUp: Variants = {
  hidden: {
    opacity: 0,
    y: 30,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: easings.gentle,
    },
  },
};

// Stagger container for lists
export const staggerContainer: Variants = {
  hidden: {
    opacity: 0,
  },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

// Individual list item
export const staggerItem: Variants = {
  hidden: {
    opacity: 0,
    x: -20,
  },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      ease: easings.gentle,
    },
  },
};

// Search input focus animation
export const searchFocus: Variants = {
  unfocused: {
    scale: 1,
    borderColor: 'var(--border)',
  },
  focused: {
    scale: 1.02,
    borderColor: 'var(--primary)',
    transition: {
      duration: 0.3,
      ease: easings.gentle,
    },
  },
};

// Button interaction states
export const buttonMotion: Variants = {
  rest: {
    scale: 1,
    transition: {
      duration: 0.2,
      ease: easings.gentle,
    },
  },
  hover: {
    scale: 1.05,
    transition: {
      duration: 0.2,
      ease: easings.gentle,
    },
  },
  tap: {
    scale: 0.95,
    transition: {
      duration: 0.1,
      ease: easings.snappy,
    },
  },
};

// Loading spinner animation
export const spinnerMotion: Variants = {
  spinning: {
    rotate: 360,
    transition: {
      duration: 1,
      ease: 'linear',
      repeat: Infinity,
    },
  },
};

// Modal/Dialog animations
export const modalMotion: Variants = {
  hidden: {
    opacity: 0,
    scale: 0.9,
    y: 20,
  },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: easings.bounce,
    },
  },
  exit: {
    opacity: 0,
    scale: 0.9,
    y: 20,
    transition: {
      duration: 0.3,
      ease: easings.gentle,
    },
  },
};

// Hero section entrance
export const heroMotion: Variants = {
  hidden: {
    opacity: 0,
    y: 40,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 1,
      ease: easings.gentle,
      staggerChildren: 0.2,
    },
  },
};

// Badge pulse animation (performance optimized)
export const badgePulse: Variants = {
  rest: {
    scale: 1,
    opacity: 1,
  },
  pulse: {
    scale: [1, 1.05, 1],
    opacity: [1, 0.8, 1],
    transition: {
      duration: 2,
      repeat: Infinity,
      ease: easings.gentle,
    },
  },
};

// Chart animation variants
export const chartMotion: Variants = {
  hidden: {
    scale: 0.8,
    opacity: 0,
  },
  visible: {
    scale: 1,
    opacity: 1,
    transition: {
      duration: 0.8,
      ease: easings.bounce,
      delay: 0.2,
    },
  },
};

// Utility function to create viewport-triggered animations
export const createViewportAnimation = (
  threshold = 0.1,
  once = true
) => ({
  viewport: { once, amount: threshold },
  initial: 'hidden',
  whileInView: 'visible',
});

// Common transition presets
export const transitions = {
  fast: { duration: 0.2, ease: easings.snappy },
  medium: { duration: 0.4, ease: easings.gentle },
  slow: { duration: 0.8, ease: easings.gentle },
  bouncy: { duration: 0.6, ease: easings.bounce },
} as const;

// Reduced motion variants (respects prefers-reduced-motion)
export const reducedMotion = {
  initial: { opacity: 0 },
  animate: { opacity: 1, transition: { duration: 0.3 } },
  exit: { opacity: 0, transition: { duration: 0.2 } },
};

// Page router transition wrapper (requires AnimatePresence at route level)
export const routerTransition: Variants = {
  initial: {
    opacity: 0,
    x: 20,
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.4,
      ease: easings.gentle,
    },
  },
  exit: {
    opacity: 0,
    x: -20,
    transition: {
      duration: 0.3,
      ease: easings.gentle,
    },
  },
};