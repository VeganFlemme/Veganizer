// Landing page for logged out users with quick recipe conversion - referencing blueprint:javascript_log_in_with_replit
import { useState } from "react";
import logoPath from "@assets/logo2.svg";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChefHat, Leaf, Globe, Sparkles, Heart } from "lucide-react";
import SearchSection from "@/components/SearchSection";
import RecipeComparison from "@/components/RecipeComparison";
import NutritionAnalysis from "@/components/NutritionAnalysis";
import AnimalSavings from "@/components/AnimalSavings";
import { RecipeComparisonSkeleton, NutritionAnalysisSkeleton, EmptyState } from "@/components/animated";
import { type RecipeConversionResponse } from "@shared/schema";
import { AnimatePresence, motion } from "framer-motion";
import { useAuth } from "@/hooks/useAuth";

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const [conversionResult, setConversionResult] = useState<RecipeConversionResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleConversionResult = (result: RecipeConversionResponse) => {
    setConversionResult(result);
    setIsLoading(false);
    setHasSearched(true);
    // Auto scroll to results after conversion
    setTimeout(() => {
      document.getElementById('comparison-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleConversionStart = () => {
    setIsLoading(true);
    setHasSearched(true);
    setConversionResult(null);
  };

  const handleConversionError = () => {
    setIsLoading(false);
    setHasSearched(true);
    setConversionResult(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-800">
      <main id="main-content" className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-16">
          <div className="flex items-center gap-2">
            <img 
              src={logoPath} 
              alt="Veganizer Logo" 
              className="w-16 h-16 md:w-18 md:h-18 lg:w-20 lg:h-20 xl:w-24 xl:h-24 rounded-lg object-contain"
            />
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Veganizer
            </h1>
          </div>
          <Button 
            onClick={() => window.location.href = '/api/login'} 
            variant="outline"
            className="border-gray-200 hover:bg-gray-50 text-gray-900 dark:border-gray-700 dark:hover:bg-gray-800 dark:text-gray-100"
            data-testid="button-login"
          >
            Se connecter
          </Button>
        </div>

        {/* Quick Recipe Conversion Section */}
        <section id="search-section" className="mb-16">
          <div className="text-center mb-12">
          </div>
          
          <SearchSection 
            onConversionResult={handleConversionResult}
            onConversionStart={handleConversionStart}
            onConversionError={handleConversionError}
          />
          
          {/* Loading State */}
          {isLoading && (
            <div className="mt-12">
              <RecipeComparisonSkeleton />
              <NutritionAnalysisSkeleton />
            </div>
          )}
          
          {/* Empty State - No Results */}
          {!conversionResult && !isLoading && hasSearched && (
            <div className="mt-12">
              <EmptyState
                icon={<ChefHat className="w-12 h-12" />}
                title="Aucun résultat trouvé"
                description="Nous n'avons pas pu trouver de correspondance pour cette recette. Essayez avec un autre nom ou vérifiez l'orthographe."
                action={
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Sparkles className="w-4 h-4" />
                    <span>Essayez : Coq au vin, Blanquette de veau, Lasagnes...</span>
                  </div>
                }
              />
            </div>
          )}
        </section>

        {/* Features - moved up to be right after search */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <Card className="text-center border-border">
            <CardHeader>
              <ChefHat className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <CardTitle className="text-gray-900 dark:text-white">
                Végétalisez vos recettes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-600 dark:text-gray-300">
                Convertissez instantanément vos recettes préférées avec des substitutions veganes intelligentes
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-border">
            <CardHeader>
              <Leaf className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <CardTitle className="text-gray-900 dark:text-white">
                Analyse nutritionnelle
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-600 dark:text-gray-300">
                Obtenez des analyses détaillées avec la base Ciqual française et des recommandations personnalisées
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-border">
            <CardHeader>
              <Globe className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <CardTitle className="text-gray-900 dark:text-white">
                Impact climatique
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-600 dark:text-gray-300">
                Visualisez l'impact environnemental de vos choix avec les données AGRIBALYSE
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-border">
            <CardHeader>
              <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <CardTitle className="text-gray-900 dark:text-white">
                Animaux sauvés
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-600 dark:text-gray-300">
                Découvrez combien d'animaux vous sauvez en choisissant des alternatives véganes
              </CardDescription>
            </CardContent>
          </Card>
        </div>
        
        {/* Recipe Results Section */}
        <AnimatePresence>
          {conversionResult && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8 mb-16"
            >
              {/* Recipe Comparison */}
              <motion.section 
                id="comparison-section"
                className="scroll-mt-24"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <Card className="h-full border border-border">
                  <div className="p-5 md:p-6 lg:p-8 space-y-6">
                    <div className="text-center space-y-3">
                      <div className="flex items-center justify-center gap-3 mb-4">
                        <Leaf className="w-6 h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 text-muted-foreground" />
                        <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground">Comparaison</h3>
                      </div>
                    </div>
                    
                    <RecipeComparison
                      originalRecipe={conversionResult.originalRecipe}
                      veganRecipe={conversionResult.veganRecipe}
                      substitutionCount={conversionResult.substitutionCount}
                      conversionResult={conversionResult}
                    />
                  </div>
                </Card>
              </motion.section>
              
              {/* Nutrition Analysis */}
              <motion.section 
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Card className="h-full border border-border">
                  <div className="p-5 md:p-6 lg:p-8">
                    <div className="text-center mb-6">
                      <div className="flex items-center justify-center gap-3 mb-4">
                        <ChefHat className="w-6 h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 text-muted-foreground" />
                        <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground">Analyse Nutritionnelle</h3>
                      </div>
                    </div>
                    
                    <NutritionAnalysis
                      nutritionComparison={conversionResult.nutritionComparison}
                    />
                  </div>
                </Card>
              </motion.section>
              
              {/* Climate Impact Analysis */}
              <motion.section 
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <Card className="h-full border border-border">
                  <div className="p-5 md:p-6 lg:p-8 space-y-6">
                    <div className="text-center space-y-3">
                      <div className="flex items-center justify-center gap-3 mb-4">
                        <Globe className="w-6 h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 text-muted-foreground" />
                        <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground">Impact Environnemental</h3>
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      <div className="text-center">
                        <Globe className="w-14 h-14 md:w-18 md:h-18 lg:w-20 lg:h-20 text-muted-foreground mx-auto mb-4" />
                        <h4 className="text-lg md:text-xl lg:text-2xl font-semibold mb-6">Réduction d'Impact</h4>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
                        <div className="text-center p-4 bg-accent dark:bg-accent rounded-lg border border-border">
                          <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-muted-foreground mb-2" data-testid="text-co2-reduction">
                            {conversionResult.climateComparison.co2Reduction > 0 ? '-' : '+'}{Math.abs(conversionResult.climateComparison.co2Reduction).toFixed(0)}%
                          </div>
                          <div className="text-sm md:text-base text-muted-foreground">CO₂ Émissions</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Impact carbone réduit
                          </div>
                        </div>
                        
                        <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/10 rounded-lg border border-blue-200 dark:border-blue-800/30">
                          <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2" data-testid="text-water-reduction">
                            {conversionResult.climateComparison.waterSaving > 0 ? '-' : '+'}{Math.abs(conversionResult.climateComparison.waterSaving).toFixed(0)}%
                          </div>
                          <div className="text-sm md:text-base text-muted-foreground">Consommation d'eau</div>
                          <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                            Eau préservée
                          </div>
                        </div>
                        
                        <div className="text-center p-4 bg-amber-50 dark:bg-amber-900/10 rounded-lg border border-amber-200 dark:border-amber-800/30">
                          <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-amber-600 dark:text-amber-400 mb-2" data-testid="text-land-reduction">
                            {conversionResult.climateComparison.landSaving > 0 ? '-' : '+'}{Math.abs(conversionResult.climateComparison.landSaving).toFixed(0)}%
                          </div>
                          <div className="text-sm md:text-base text-muted-foreground">Usage des terres</div>
                          <div className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                            Terres préservées
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-center p-4 bg-accent dark:bg-accent rounded-lg border border-border">
                        <p className="text-sm text-muted-foreground">
                          🌱 <strong>Impact positif :</strong> En choisissant cette version végane, vous contribuez à réduire l'empreinte environnementale de votre alimentation.
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.section>
              
              {/* Animal Savings */}
              <motion.section 
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <AnimalSavings animalSavings={conversionResult.animalSavings} />
              </motion.section>
              
              {/* Call to Action after results - only show when not authenticated */}
              {!isAuthenticated && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.5 }}
                  className="text-center bg-accent dark:bg-accent rounded-lg p-8"
                >
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                    Vous aimez ce que vous voyez ?
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    Connectez-vous pour sauvegarder vos recettes et créer des menus personnalisés
                  </p>
                  <Button 
                    onClick={() => window.location.href = '/api/login'} 
                    size="lg"
                    className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-3 dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-gray-900"
                    data-testid="button-cta-after-results"
                  >
                    Se connecter maintenant
                  </Button>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>



        {/* Final Call to Action - shown when no results and not authenticated */}
        {!conversionResult && !isAuthenticated && (
          <div className="text-center bg-accent dark:bg-accent rounded-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Prêt à créer votre plan alimentaire personnalisé ?
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Connectez-vous avec Google, Apple ou votre email pour accéder à toutes les fonctionnalités
            </p>
            <Button 
              onClick={() => window.location.href = '/api/login'} 
              size="lg"
              className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-3 dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-gray-900"
              data-testid="button-cta-login"
            >
              Se connecter maintenant
            </Button>
          </div>
        )}
      </main>

    </div>
  );
}