import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings, 
  LogIn, 
  LogOut, 
  BarChart3, 
  Database, 
  Users, 
  ChefHat, 
  Link,
  Download,
  Upload,
  Trash2,
  Edit,
  Plus,
  Eye
} from "lucide-react";

// Form schemas
const loginSchema = z.object({
  secret: z.string().min(1, "Mot de passe administrateur requis"),
});

const recipeSchema = z.object({
  name: z.string().min(1, "Nom requis"),
  ingredient1: z.string().optional(),
  ingredient2: z.string().optional(),
  ingredient3: z.string().optional(),
  ingredient4: z.string().optional(),
  ingredient5: z.string().optional(),
  ingredient6: z.string().optional(),
  vegan_ingredient1: z.string().optional(),
  vegan_ingredient2: z.string().optional(),
  vegan_ingredient3: z.string().optional(),
  vegan_ingredient4: z.string().optional(),
  vegan_ingredient5: z.string().optional(),
  vegan_ingredient6: z.string().optional(),
});

const substitutionSchema = z.object({
  original_ingredient: z.string().min(1, "Ingrédient original requis"),
  vegan_alternative: z.string().min(1, "Alternative végane requise"),
  ratio: z.number().min(0.1).max(5).default(1),
  category: z.string().optional(),
});

interface AdminStats {
  recipes: number;
  substitutions: number;
  ciqual_data: number;
  users: number;
  favorites: number;
  timestamp: string;
  database_status: string;
}

interface AdminRecipe {
  id: string;
  name: string;
  ingredient1?: string;
  ingredient2?: string;
  ingredient3?: string;
  ingredient4?: string;
  ingredient5?: string;
  ingredient6?: string;
  vegan_ingredient1?: string;
  vegan_ingredient2?: string;
  vegan_ingredient3?: string;
  vegan_ingredient4?: string;
  vegan_ingredient5?: string;
  vegan_ingredient6?: string;
}

interface AdminSubstitution {
  id: string;
  original_ingredient: string;
  vegan_alternative: string;
  ratio: number;
  category?: string;
}

interface AdminUser {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  createdAt?: string;
  updatedAt?: string;
}

interface AdminFavorite {
  id: string;
  user_id: string;
  recipe_name: string;
  vegan_recipe_name: string;
  created_at: string;
}

export default function Admin() {
  const { toast } = useToast();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [activeTab, setActiveTab] = useState("stats");

  // Check if admin is already logged in
  useEffect(() => {
    checkAdminAuth();
  }, []);

  const checkAdminAuth = async () => {
    try {
      const response = await apiRequest('GET', '/api/admin/me');
      if (response.ok) {
        const data = await response.json();
        setIsLoggedIn(data.isAdmin === true);
      }
    } catch {
      setIsLoggedIn(false);
    }
  };

  // Login form
  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { secret: "" },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: { secret: string }) => {
      const response = await apiRequest('POST', '/api/admin/login', data);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.isAdmin) {
        setIsLoggedIn(true);
        toast({
          title: "Connexion réussie",
          description: "Vous êtes maintenant connecté en tant qu'administrateur.",
        });
      }
    },
    onError: () => {
      toast({
        title: "Erreur de connexion",
        description: "Mot de passe administrateur incorrect.",
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/logout');
      return response.json();
    },
    onSuccess: () => {
      setIsLoggedIn(false);
      toast({
        title: "Déconnexion réussie",
        description: "Vous avez été déconnecté.",
      });
    },
  });

  // Data queries
  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ['/api/admin/stats'],
    enabled: isLoggedIn,
  });

  const { data: recipesData, isLoading: recipesLoading } = useQuery<{ data: AdminRecipe[], pagination: any }>({
    queryKey: ['/api/admin/recipes', { page: 1, limit: 20 }],
    enabled: isLoggedIn && activeTab === 'recipes',
  });

  const { data: substitutionsData, isLoading: substitutionsLoading } = useQuery<{ data: AdminSubstitution[], pagination: any }>({
    queryKey: ['/api/admin/substitutions', { page: 1, limit: 20 }],
    enabled: isLoggedIn && activeTab === 'substitutions',
  });

  const { data: usersData, isLoading: usersLoading } = useQuery<{ data: AdminUser[], pagination: any }>({
    queryKey: ['/api/admin/users', { page: 1, limit: 20 }],
    enabled: isLoggedIn && activeTab === 'users',
  });

  const { data: favoritesData, isLoading: favoritesLoading } = useQuery<{ data: AdminFavorite[], pagination: any }>({
    queryKey: ['/api/admin/favorites', { page: 1, limit: 20 }],
    enabled: isLoggedIn && activeTab === 'users',
  });

  // Recipe management
  const recipeForm = useForm({
    resolver: zodResolver(recipeSchema),
    defaultValues: {
      name: "",
      ingredient1: "",
      ingredient2: "",
      ingredient3: "",
      ingredient4: "",
      ingredient5: "",
      ingredient6: "",
      vegan_ingredient1: "",
      vegan_ingredient2: "",
      vegan_ingredient3: "",
      vegan_ingredient4: "",
      vegan_ingredient5: "",
      vegan_ingredient6: "",
    },
  });

  const createRecipeMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/admin/recipes', data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Recette créée", description: "La recette a été ajoutée avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/recipes'] });
      recipeForm.reset();
      setIsEditDialogOpen(false);
    },
  });

  const updateRecipeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string, data: any }) => {
      const response = await apiRequest('PATCH', `/api/admin/recipes/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Recette mise à jour", description: "La recette a été modifiée avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/recipes'] });
      setIsEditDialogOpen(false);
      setEditingItem(null);
    },
  });

  const deleteRecipeMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/admin/recipes/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Recette supprimée", description: "La recette a été supprimée avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/recipes'] });
    },
  });

  // Substitution management
  const substitutionForm = useForm({
    resolver: zodResolver(substitutionSchema),
    defaultValues: {
      original_ingredient: "",
      vegan_alternative: "",
      ratio: 1,
      category: "",
    },
  });

  const createSubstitutionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/admin/substitutions', data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Substitution créée", description: "La substitution a été ajoutée avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/substitutions'] });
      substitutionForm.reset();
      setIsEditDialogOpen(false);
    },
  });

  const updateSubstitutionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string, data: any }) => {
      const response = await apiRequest('PATCH', `/api/admin/substitutions/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Substitution mise à jour", description: "La substitution a été modifiée avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/substitutions'] });
      setIsEditDialogOpen(false);
      setEditingItem(null);
    },
  });

  const deleteSubstitutionMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/admin/substitutions/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Substitution supprimée", description: "La substitution a été supprimée avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/substitutions'] });
    },
  });

  const deleteFavoriteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/admin/favorites/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Favori supprimé", description: "Le favori a été supprimé avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/favorites'] });
    },
  });

  // Admin tools mutations
  const importCsvMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('csvFile', file);
      const response = await apiRequest('POST', '/api/import', formData);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Import réussi", description: "Les données CSV ont été importées avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
    },
    onError: () => {
      toast({ title: "Erreur d'import", description: "Impossible d'importer le fichier CSV.", variant: "destructive" });
    },
  });

  const linkIngredientsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/link-ingredients');
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Liaison réussie", description: "Les ingrédients ont été liés avec succès." });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
    },
  });

  // Handle form submissions
  const handleLogin = (data: { secret: string }) => {
    loginMutation.mutate(data);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleCreateRecipe = (data: any) => {
    createRecipeMutation.mutate(data);
  };

  const handleUpdateRecipe = (data: any) => {
    if (editingItem) {
      updateRecipeMutation.mutate({ id: editingItem.id, data });
    }
  };

  const handleCreateSubstitution = (data: any) => {
    createSubstitutionMutation.mutate(data);
  };

  const handleUpdateSubstitution = (data: any) => {
    if (editingItem) {
      updateSubstitutionMutation.mutate({ id: editingItem.id, data });
    }
  };

  const openEditDialog = (item: any, type: 'recipe' | 'substitution') => {
    setEditingItem(item);
    if (type === 'recipe') {
      recipeForm.reset(item);
    } else {
      substitutionForm.reset(item);
    }
    setIsEditDialogOpen(true);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      importCsvMutation.mutate(file);
    }
  };

  // Login screen
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-800 flex items-center justify-center">
        <Card data-variant="glass" className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Settings className="w-12 h-12 text-primary" />
            </div>
            <CardTitle className="text-2xl">Administration Veganizer</CardTitle>
            <CardDescription>
              Connectez-vous pour accéder au panneau d'administration
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="secret"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mot de passe administrateur</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Entrez le mot de passe"
                          data-testid="input-admin-password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full"
                  disabled={loginMutation.isPending}
                  data-testid="button-admin-login"
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  {loginMutation.isPending ? "Connexion..." : "Se connecter"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Admin dashboard
  return (
    <div className="min-h-screen bg-background font-sans">
      <header className="border-b bg-white dark:bg-gray-950">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Settings className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Administration Veganizer
                </h1>
                <p className="text-sm text-muted-foreground">
                  Gestion des données et configuration
                </p>
              </div>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              data-testid="button-admin-logout"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Déconnexion
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="stats" data-testid="tab-stats">
              <BarChart3 className="w-4 h-4 mr-2" />
              Statistiques
            </TabsTrigger>
            <TabsTrigger value="recipes" data-testid="tab-recipes">
              <ChefHat className="w-4 h-4 mr-2" />
              Recettes
            </TabsTrigger>
            <TabsTrigger value="substitutions" data-testid="tab-substitutions">
              <Link className="w-4 h-4 mr-2" />
              Substitutions
            </TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">
              <Users className="w-4 h-4 mr-2" />
              Utilisateurs
            </TabsTrigger>
            <TabsTrigger value="tools" data-testid="tab-tools">
              <Database className="w-4 h-4 mr-2" />
              Outils
            </TabsTrigger>
          </TabsList>

          {/* Statistics Tab */}
          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {statsLoading ? (
                <div className="col-span-full text-center">Chargement des statistiques...</div>
              ) : stats ? (
                <>
                  <Card data-variant="elevated">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Recettes</CardTitle>
                      <ChefHat className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-recipes-count">{stats.recipes}</div>
                    </CardContent>
                  </Card>
                  
                  <Card data-variant="elevated">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Substitutions</CardTitle>
                      <Link className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-substitutions-count">{stats.substitutions}</div>
                    </CardContent>
                  </Card>
                  
                  <Card data-variant="elevated">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Utilisateurs</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-users-count">{stats.users}</div>
                    </CardContent>
                  </Card>
                  
                  <Card data-variant="elevated">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Données Ciqual</CardTitle>
                      <Database className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-ciqual-count">{stats.ciqual_data}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Favoris</CardTitle>
                      <Database className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold" data-testid="text-favorites-count">{stats.favorites}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">État Base de Données</CardTitle>
                      <Database className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-sm">
                        <Badge variant={stats.database_status === 'connected' ? 'default' : 'destructive'}>
                          {stats.database_status}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Dernière MAJ: {new Date(stats.timestamp).toLocaleString('fr-FR')}
                      </div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <div className="col-span-full text-center text-muted-foreground">
                  Impossible de charger les statistiques
                </div>
              )}
            </div>
          </TabsContent>

          {/* Recipes Tab */}
          <TabsContent value="recipes" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Gestion des Recettes</h2>
              <Dialog open={isEditDialogOpen && !editingItem} onOpenChange={setIsEditDialogOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-recipe">
                    <Plus className="w-4 h-4 mr-2" />
                    Ajouter une recette
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Ajouter une nouvelle recette</DialogTitle>
                  </DialogHeader>
                  <Form {...recipeForm}>
                    <form onSubmit={recipeForm.handleSubmit(handleCreateRecipe)} className="space-y-4">
                      <FormField
                        control={recipeForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nom de la recette</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid="input-recipe-name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-4">
                          <h4 className="font-medium">Ingrédients originaux</h4>
                          {[1, 2, 3, 4, 5, 6].map((i) => (
                            <FormField
                              key={i}
                              control={recipeForm.control}
                              name={`ingredient${i}` as keyof typeof recipeForm.control._defaultValues}
                              render={({ field }) => (
                                <FormItem>
                                  <FormControl>
                                    <Input 
                                      placeholder={`Ingrédient ${i}`} 
                                      data-testid={`input-ingredient-${i}`}
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                        
                        <div className="space-y-4">
                          <h4 className="font-medium">Ingrédients véganes</h4>
                          {[1, 2, 3, 4, 5, 6].map((i) => (
                            <FormField
                              key={i}
                              control={recipeForm.control}
                              name={`vegan_ingredient${i}` as keyof typeof recipeForm.control._defaultValues}
                              render={({ field }) => (
                                <FormItem>
                                  <FormControl>
                                    <Input 
                                      placeholder={`Ingrédient végan ${i}`} 
                                      data-testid={`input-vegan-ingredient-${i}`}
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                          Annuler
                        </Button>
                        <Button type="submit" disabled={createRecipeMutation.isPending} data-testid="button-save-recipe">
                          {createRecipeMutation.isPending ? "Enregistrement..." : "Enregistrer"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <Card>
              <CardContent>
                {recipesLoading ? (
                  <div className="text-center py-8">Chargement des recettes...</div>
                ) : recipesData?.data ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nom</TableHead>
                        <TableHead>Ingrédients originaux</TableHead>
                        <TableHead>Ingrédients véganes</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recipesData.data.map((recipe) => (
                        <TableRow key={recipe.id}>
                          <TableCell className="font-medium">{recipe.name}</TableCell>
                          <TableCell>
                            <div className="text-sm space-y-1">
                              {[recipe.ingredient1, recipe.ingredient2, recipe.ingredient3, recipe.ingredient4, recipe.ingredient5, recipe.ingredient6]
                                .filter(Boolean)
                                .map((ing, i) => (
                                  <div key={i}>{ing}</div>
                                ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm space-y-1">
                              {[recipe.vegan_ingredient1, recipe.vegan_ingredient2, recipe.vegan_ingredient3, recipe.vegan_ingredient4, recipe.vegan_ingredient5, recipe.vegan_ingredient6]
                                .filter(Boolean)
                                .map((ing, i) => (
                                  <div key={i}>{ing}</div>
                                ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => openEditDialog(recipe, 'recipe')}
                                data-testid={`button-edit-recipe-${recipe.id}`}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteRecipeMutation.mutate(recipe.id)}
                                data-testid={`button-delete-recipe-${recipe.id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    Aucune recette trouvée
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Edit Recipe Dialog */}
            <Dialog open={isEditDialogOpen && editingItem && !editingItem.original_ingredient} onOpenChange={(open) => {
              setIsEditDialogOpen(open);
              if (!open) setEditingItem(null);
            }}>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Modifier la recette</DialogTitle>
                </DialogHeader>
                <Form {...recipeForm}>
                  <form onSubmit={recipeForm.handleSubmit(handleUpdateRecipe)} className="space-y-4">
                    <FormField
                      control={recipeForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nom de la recette</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-edit-recipe-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-4">
                        <h4 className="font-medium">Ingrédients originaux</h4>
                        {[1, 2, 3, 4, 5, 6].map((i) => (
                          <FormField
                            key={i}
                            control={recipeForm.control}
                            name={`ingredient${i}` as keyof typeof recipeForm.control._defaultValues}
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Input 
                                    placeholder={`Ingrédient ${i}`} 
                                    data-testid={`input-edit-ingredient-${i}`}
                                    {...field} 
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      
                      <div className="space-y-4">
                        <h4 className="font-medium">Ingrédients véganes</h4>
                        {[1, 2, 3, 4, 5, 6].map((i) => (
                          <FormField
                            key={i}
                            control={recipeForm.control}
                            name={`vegan_ingredient${i}` as keyof typeof recipeForm.control._defaultValues}
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Input 
                                    placeholder={`Ingrédient végan ${i}`} 
                                    data-testid={`input-edit-vegan-ingredient-${i}`}
                                    {...field} 
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                        Annuler
                      </Button>
                      <Button type="submit" disabled={updateRecipeMutation.isPending} data-testid="button-update-recipe">
                        {updateRecipeMutation.isPending ? "Mise à jour..." : "Mettre à jour"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </TabsContent>

          {/* Substitutions Tab */}
          <TabsContent value="substitutions" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Gestion des Substitutions</h2>
              <Dialog open={isEditDialogOpen && !editingItem} onOpenChange={setIsEditDialogOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-substitution">
                    <Plus className="w-4 h-4 mr-2" />
                    Ajouter une substitution
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Ajouter une nouvelle substitution</DialogTitle>
                  </DialogHeader>
                  <Form {...substitutionForm}>
                    <form onSubmit={substitutionForm.handleSubmit(handleCreateSubstitution)} className="space-y-4">
                      <FormField
                        control={substitutionForm.control}
                        name="original_ingredient"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Ingrédient original</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid="input-original-ingredient" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={substitutionForm.control}
                        name="vegan_alternative"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Alternative végane</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid="input-vegan-alternative" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={substitutionForm.control}
                        name="ratio"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Ratio de substitution</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.1" 
                                min="0.1" 
                                max="5" 
                                data-testid="input-ratio"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={substitutionForm.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Catégorie (optionnel)</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid="input-category" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end space-x-2">
                        <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                          Annuler
                        </Button>
                        <Button type="submit" disabled={createSubstitutionMutation.isPending} data-testid="button-save-substitution">
                          {createSubstitutionMutation.isPending ? "Enregistrement..." : "Enregistrer"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <Card>
              <CardContent>
                {substitutionsLoading ? (
                  <div className="text-center py-8">Chargement des substitutions...</div>
                ) : substitutionsData?.data ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Ingrédient original</TableHead>
                        <TableHead>Alternative végane</TableHead>
                        <TableHead>Ratio</TableHead>
                        <TableHead>Catégorie</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {substitutionsData.data.map((substitution) => (
                        <TableRow key={substitution.id}>
                          <TableCell className="font-medium">{substitution.original_ingredient}</TableCell>
                          <TableCell>{substitution.vegan_alternative}</TableCell>
                          <TableCell>{substitution.ratio}</TableCell>
                          <TableCell>{substitution.category || '-'}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => openEditDialog(substitution, 'substitution')}
                                data-testid={`button-edit-substitution-${substitution.id}`}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteSubstitutionMutation.mutate(substitution.id)}
                                data-testid={`button-delete-substitution-${substitution.id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    Aucune substitution trouvée
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Edit Substitution Dialog */}
            <Dialog open={isEditDialogOpen && editingItem && editingItem.original_ingredient} onOpenChange={(open) => {
              setIsEditDialogOpen(open);
              if (!open) setEditingItem(null);
            }}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Modifier la substitution</DialogTitle>
                </DialogHeader>
                <Form {...substitutionForm}>
                  <form onSubmit={substitutionForm.handleSubmit(handleUpdateSubstitution)} className="space-y-4">
                    <FormField
                      control={substitutionForm.control}
                      name="original_ingredient"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ingrédient original</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-edit-original-ingredient" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={substitutionForm.control}
                      name="vegan_alternative"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Alternative végane</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-edit-vegan-alternative" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={substitutionForm.control}
                      name="ratio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ratio de substitution</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.1" 
                              min="0.1" 
                              max="5"
                              data-testid="input-edit-ratio"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={substitutionForm.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Catégorie (optionnel)</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-edit-category" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                        Annuler
                      </Button>
                      <Button type="submit" disabled={updateSubstitutionMutation.isPending} data-testid="button-update-substitution">
                        {updateSubstitutionMutation.isPending ? "Mise à jour..." : "Mettre à jour"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Gestion des Utilisateurs</h2>
              <Badge variant="secondary">Lecture seule</Badge>
            </div>

            <Card>
              <CardContent>
                {usersLoading ? (
                  <div className="text-center py-8">Chargement des utilisateurs...</div>
                ) : usersData?.data ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Nom complet</TableHead>
                        <TableHead>Créé le</TableHead>
                        <TableHead>Dernière MAJ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {usersData.data.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-mono text-xs">{user.id}</TableCell>
                          <TableCell>{user.email || '-'}</TableCell>
                          <TableCell>
                            {user.firstName || user.lastName ? 
                              `${user.firstName || ''} ${user.lastName || ''}`.trim() : 
                              '-'
                            }
                          </TableCell>
                          <TableCell>
                            {user.createdAt ? new Date(user.createdAt).toLocaleDateString('fr-FR') : '-'}
                          </TableCell>
                          <TableCell>
                            {user.updatedAt ? new Date(user.updatedAt).toLocaleDateString('fr-FR') : '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    Aucun utilisateur trouvé
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Favorites Section */}
            <Card>
              <CardHeader>
                <CardTitle>Favoris des utilisateurs</CardTitle>
                <CardDescription>
                  Gestion des recettes favorites sauvegardées par les utilisateurs
                </CardDescription>
              </CardHeader>
              <CardContent>
                {favoritesLoading ? (
                  <div className="text-center py-8">Chargement des favoris...</div>
                ) : favoritesData?.data ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Utilisateur</TableHead>
                        <TableHead>Recette originale</TableHead>
                        <TableHead>Recette végane</TableHead>
                        <TableHead>Créé le</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {favoritesData.data.map((favorite) => (
                        <TableRow key={favorite.id}>
                          <TableCell className="font-mono text-xs">{favorite.user_id}</TableCell>
                          <TableCell>{favorite.recipe_name}</TableCell>
                          <TableCell>{favorite.vegan_recipe_name}</TableCell>
                          <TableCell>
                            {new Date(favorite.created_at).toLocaleDateString('fr-FR')}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteFavoriteMutation.mutate(favorite.id)}
                              data-testid={`button-delete-favorite-${favorite.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    Aucun favori trouvé
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tools Tab */}
          <TabsContent value="tools" className="space-y-6">
            <h2 className="text-2xl font-bold">Outils d'Administration</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="w-5 h-5" />
                    Import CSV
                  </CardTitle>
                  <CardDescription>
                    Importer des recettes depuis un fichier CSV
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Input
                      type="file"
                      accept=".csv"
                      onChange={handleFileUpload}
                      data-testid="input-csv-file"
                    />
                    <p className="text-sm text-muted-foreground">
                      Format attendu: nom,ingredient1,ingredient2,...,vegan_ingredient1,vegan_ingredient2,...
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link className="w-5 h-5" />
                    Liaison des Ingrédients
                  </CardTitle>
                  <CardDescription>
                    Lier automatiquement les ingrédients avec la base Ciqual
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={() => linkIngredientsMutation.mutate()}
                    disabled={linkIngredientsMutation.isPending}
                    className="w-full"
                    data-testid="button-link-ingredients"
                  >
                    {linkIngredientsMutation.isPending ? "Liaison en cours..." : "Lancer la liaison"}
                  </Button>
                  <p className="text-sm text-muted-foreground mt-2">
                    Processus automatique de correspondance des ingrédients
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}