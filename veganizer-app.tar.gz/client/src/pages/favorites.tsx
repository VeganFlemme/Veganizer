import { useState } from "react";
import Header from "@/components/Header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Heart, X, Clock, Users, Flame, Search, Leaf } from "lucide-react";
import { type Favorite, type RecipeConversionResponse } from "@shared/schema";
import NutritionDashboard from "@/components/NutritionDashboard";
import { EmptyState } from "@/components/animated";
import { Link } from "wouter";

export default function Favorites() {
  const { toast } = useToast();

  const { data: favorites, isLoading } = useQuery<Favorite[]>({
    queryKey: ['/api/favorites'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/favorites');
      return response.json() as Promise<Favorite[]>;
    },
  });

  const deleteFavoriteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/favorites/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Plat supprimé",
        description: "Le plat a été retiré de votre plan alimentaire.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
    },
  });





  if (isLoading) {
    return (
      <div className="min-h-screen bg-background font-sans">
        <Header />
        <main className="container mx-auto px-4 py-8 max-w-6xl">
          <div className="text-center">Chargement de votre plan alimentaire...</div>
        </main>
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-background font-sans">
      <Header />
      
      <main id="main-content" className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2 flex items-center gap-3">
            <Heart className="w-8 h-8 text-primary" />
            Mon Plan Alimentaire
          </h1>
          <p className="text-muted-foreground">
            Vos recettes véganes et suivi nutritionnel personnalisé
          </p>
        </div>

        {!favorites || favorites.length === 0 ? (
          <EmptyState
            icon={<Heart className="w-16 h-16" />}
            title="Aucun plat dans votre plan"
            description="Découvrez et convertissez vos recettes préférées en version végétale pour créer votre plan alimentaire personnalisé."
            action={
              <Link href="/">
                <button className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors interactive-link" data-testid="button-start-converting">
                  <Search className="w-4 h-4" />
                  Découvrir les recettes
                </button>
              </Link>
            }
          />
        ) : (
          <>
            {/* Favorite Recipes List */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">Mes Plats ({favorites.length})</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {favorites.map((favorite) => {
                  const recipeData = JSON.parse(favorite.recipe_data) as RecipeConversionResponse;
                  return (
                    <Card key={favorite.id} data-variant="elevated">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-1" data-testid={`favorite-recipe-${favorite.id}`}>
                              {favorite.vegan_recipe_name}
                            </h3>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteFavoriteMutation.mutate(favorite.id)}
                            disabled={deleteFavoriteMutation.isPending}
                            className="h-8 w-8 p-0 hover:bg-destructive/10"
                            data-testid={`button-delete-favorite-${favorite.id}`}
                          >
                            <X className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>

                        <div className="flex items-center text-muted-foreground text-sm space-x-4 mb-4">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {recipeData.veganRecipe.cookingTime}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {recipeData.veganRecipe.servings} pers.
                          </span>
                          <span className="flex items-center gap-1">
                            <Flame className="w-4 h-4" />
                            {recipeData.veganRecipe.difficulty}
                          </span>
                        </div>

                        <div className="text-sm text-muted-foreground">
                          <strong>{recipeData.substitutionCount}</strong> substitutions • 
                          <strong className="ml-1">{recipeData.veganRecipe.ingredients.length}</strong> ingrédients
                        </div>

                        <div className="text-xs text-muted-foreground mt-2">
                          Ajoutée le {new Date(favorite.created_at).toLocaleDateString('fr-FR')}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </section>
            

            {/* Nutrition Dashboard */}
            <NutritionDashboard favorites={favorites} />
          </>
        )}
      </main>
    </div>
  );
}