import { useState, useEffect } from "react";
import Header from "@/components/Header";
import SearchSection from "@/components/SearchSection";
import RecipeComparison from "@/components/RecipeComparison";
import NutritionAnalysis from "@/components/NutritionAnalysis";
import NutritionDashboard from "@/components/NutritionDashboard";
import AnimalSavings from "@/components/AnimalSavings";
import { RecipeComparisonSkeleton, NutritionAnalysisSkeleton, EmptyState } from "@/components/animated";
import { type RecipeConversionResponse, type Favorite } from "@shared/schema";
import { ChefHat, Sparkles, Leaf, Heart, BarChart3, Globe, ExternalLink, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const [conversionResult, setConversionResult] = useState<RecipeConversionResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [activeSection, setActiveSection] = useState('search');

  // Fetch favorites for the favorites section with loading and error states
  const { data: favorites, isLoading: isLoadingFavorites, isError: favoritesError } = useQuery<Favorite[]>({
    queryKey: ['/api/favorites'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/favorites');
      return response.json() as Promise<Favorite[]>;
    },
  });

  const handleConversionResult = (result: RecipeConversionResponse) => {
    setConversionResult(result);
    setIsLoading(false);
    setHasSearched(true);
    // Auto scroll to results after conversion
    setTimeout(() => {
      document.getElementById('comparison-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleConversionStart = () => {
    setIsLoading(true);
    setHasSearched(true);
    setConversionResult(null);
  };

  const handleConversionError = () => {
    setIsLoading(false);
    setHasSearched(true);
    setConversionResult(null);
  };

  // Smooth scroll handler for progressive sections
  const scrollToNextSection = (currentSection: string) => {
    const sections = ['search', 'comparison', 'nutrition', 'climate', 'shopping', 'favorites'];
    const currentIndex = sections.indexOf(currentSection);
    const nextSection = sections[currentIndex + 1];
    if (nextSection) {
      document.getElementById(`${nextSection}-section`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Section visibility tracking for smooth UX
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['search', 'comparison', 'nutrition', 'climate', 'shopping', 'favorites'];
      const current = sections.find(section => {
        const element = document.getElementById(`${section}-section`);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current && current !== activeSection) {
        setActiveSection(current);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [activeSection]);

  const hasSavedMeals = (favorites?.length ?? 0) > 0;
  const canNavigate = !!conversionResult || hasSavedMeals;

  return (
    <div className="min-h-screen bg-background font-sans">
      <Header canNavigate={canNavigate} hasSavedMeals={hasSavedMeals} />
      
      <main id="main-content" className="container mx-auto px-4 md:px-6 lg:px-8 py-4 md:py-6 lg:py-8 max-w-7xl space-y-12 md:space-y-16 lg:space-y-20">
        
        {/* Section 1: Search - Hero Section */}
        <section id="search-section" className="min-h-[85vh] lg:min-h-[75vh] flex flex-col justify-center">
          <SearchSection 
            onConversionResult={handleConversionResult}
            onConversionStart={handleConversionStart}
            onConversionError={handleConversionError}
          />
          
          {/* Loading State */}
          {isLoading && (
            <div className="mt-12">
              <RecipeComparisonSkeleton />
              <NutritionAnalysisSkeleton />
            </div>
          )}
          
          {/* Empty State - No Results */}
          {!conversionResult && !isLoading && hasSearched && (
            <div className="mt-12">
              <EmptyState
                icon={<ChefHat className="w-12 h-12" />}
                title="Aucun résultat trouvé"
                description="Nous n'avons pas pu trouver de correspondance pour cette recette. Essayez avec un autre nom ou vérifiez l'orthographe."
                action={
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Sparkles className="w-4 h-4" />
                    <span>Essayez : Coq au vin, Blanquette de veau, Lasagnes...</span>
                  </div>
                }
              />
            </div>
          )}
        </section>
        
        {/* Section 2: Three Column Layout - Comparison, Nutrition, Climate */}
        <AnimatePresence>
          {conversionResult && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8 scroll-mt-24"
            >
              {/* All cards stacked vertically */}
              <div className="space-y-8 md:space-y-10 lg:space-y-12">
                {/* Recipe Comparison */}
                <motion.section 
                  id="comparison-section"
                  className="scroll-mt-24"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                >
                  <Card className="h-full glass-card border border-primary/20">
                    <div className="p-5 md:p-6 lg:p-8 space-y-6">
                      <div className="text-center space-y-3">
                        <div className="flex items-center justify-center gap-3 mb-4">
                          <Leaf className="w-6 h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 text-primary" />
                          <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground">Comparaison</h3>
                        </div>
                      </div>
                      
                      <RecipeComparison
                        originalRecipe={conversionResult.originalRecipe}
                        veganRecipe={conversionResult.veganRecipe}
                        substitutionCount={conversionResult.substitutionCount}
                        conversionResult={conversionResult}
                      />
                    </div>
                  </Card>
                </motion.section>

                {/* Nutrition Analysis */}
                <motion.section 
                  id="nutrition-section"
                  className="scroll-mt-24"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <Card className="h-full glass-card border border-accent/20">
                    <div className="p-5 md:p-6 lg:p-8 space-y-6">
                      <div className="text-center space-y-3">
                        <div className="flex items-center justify-center gap-3 mb-4">
                          <BarChart3 className="w-6 h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 text-accent" />
                          <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground">Nutrition</h3>
                        </div>
                      </div>
                      
                      <NutritionAnalysis
                        nutritionComparison={conversionResult.nutritionComparison}
                      />
                    </div>
                  </Card>
                </motion.section>

                {/* Climate Impact */}
                <motion.section 
                  id="climate-section"
                  className="scroll-mt-24"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                >
                  <Card className="h-full glass-card border border-success/20">
                    <div className="p-5 md:p-6 lg:p-8 space-y-6">
                      <div className="text-center space-y-3">
                        <div className="flex items-center justify-center gap-3 mb-4">
                          <Globe className="w-6 h-6 md:w-8 md:h-8 lg:w-10 lg:h-10 text-success" />
                          <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground">Environnement</h3>
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <Globe className="w-14 h-14 md:w-18 md:h-18 lg:w-20 lg:h-20 text-success mx-auto" />
                        <h4 className="text-lg md:text-xl lg:text-2xl font-semibold text-center">Réduction d'Impact</h4>
                        <div className="grid grid-cols-1 gap-4 lg:gap-5">
                          <div className="text-center space-y-2">
                            <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-success" data-testid="text-co2-reduction">
                              {conversionResult.climateComparison.co2Reduction > 0 ? '-' : '+'}{Math.abs(conversionResult.climateComparison.co2Reduction).toFixed(0)}%
                            </div>
                            <div className="text-sm md:text-base lg:text-lg text-muted-foreground">CO² Émissions</div>
                          </div>
                          <div className="text-center space-y-2">
                            <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-success" data-testid="text-water-reduction">
                              {conversionResult.climateComparison.waterSaving > 0 ? '-' : '+'}{Math.abs(conversionResult.climateComparison.waterSaving).toFixed(0)}%
                            </div>
                            <div className="text-sm md:text-base lg:text-lg text-muted-foreground">Consommation d'eau</div>
                          </div>
                          <div className="text-center space-y-2">
                            <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-success" data-testid="text-land-reduction">
                              {conversionResult.climateComparison.landSaving > 0 ? '-' : '+'}{Math.abs(conversionResult.climateComparison.landSaving).toFixed(0)}%
                            </div>
                            <div className="text-sm md:text-base lg:text-lg text-muted-foreground">Utilisation des terres</div>
                          </div>
                        </div>
                        <p className="text-sm md:text-base lg:text-lg text-muted-foreground text-center leading-relaxed">
                          Les substitutions végétales réduisent considérablement l'empreinte environnementale
                        </p>
                      </div>
                    </div>
                  </Card>
                </motion.section>

                {/* Animal Savings */}
                <motion.section 
                  id="animal-section"
                  className="scroll-mt-24"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                >
                  <AnimalSavings animalSavings={conversionResult.animalSavings} />
                </motion.section>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        
        {/* Section 6: Favorites & Plan Alimentaire - Only show after conversion */}
        {conversionResult && !isLoading && (
          <motion.section 
            id="favorites-section"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="space-y-8"
          >
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Heart className="w-8 h-8 text-destructive" />
              <h2 className="text-4xl font-bold text-foreground">Mon Plan Alimentaire</h2>
            </div>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Vos recettes véganes favorites et tableau de bord nutritionnel personnalisé
            </p>
          </div>
          
          {isLoadingFavorites ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Chargement de votre plan alimentaire...</p>
            </div>
          ) : favoritesError ? (
            <div className="text-center py-12 text-destructive">
              <AlertTriangle className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Erreur lors du chargement de vos favoris</p>
              <p className="text-sm text-muted-foreground">Veuillez réessayer plus tard</p>
            </div>
          ) : favorites && favorites.length > 0 ? (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {favorites.slice(0, 6).map((favorite) => {
                  let recipeData: RecipeConversionResponse;
                  try {
                    recipeData = JSON.parse(favorite.recipe_data) as RecipeConversionResponse;
                  } catch (error) {
                    console.error("Failed to parse recipe data:", error);
                    return null; // Skip rendering malformed recipes
                  }
                  
                  return (
                    <Card key={favorite.id} className="recipe-card shadow-sm">
                      <CardContent className="p-6">
                        <div className="space-y-3">
                          <div className="flex items-start justify-between">
                            <h3 className="text-lg font-semibold text-foreground" data-testid={`favorite-recipe-${favorite.id}`}>
                              {favorite.vegan_recipe_name}
                            </h3>
                          </div>
                          
                          <p className="text-sm text-muted-foreground">
                            {recipeData.substitutionCount} substitutions • {recipeData.veganRecipe.ingredients.length} ingrédients
                          </p>
                          
                          <div className="text-xs text-muted-foreground">
                            Ajoutée le {new Date(favorite.created_at).toLocaleDateString('fr-FR')}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
              
              {favorites.length > 6 && (
                <div className="text-center">
                  <p className="text-muted-foreground">Et {favorites.length - 6} autres recettes dans votre plan...</p>
                </div>
              )}
              
              <div data-testid="nutrition-dashboard-container">
                <NutritionDashboard favorites={favorites} />
              </div>
            </>
          ) : (
            <EmptyState
              icon={<Heart className="w-16 h-16" />}
              title="Commencez votre plan alimentaire"
              description="Convertissez vos recettes préférées en versions végétales pour créer votre plan personnalisé."
              action={
                <Button 
                  onClick={() => {
                    document.getElementById('search-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className="text-lg px-8 py-4"
                  data-testid="button-start-converting"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Découvrir les Recettes
                </Button>
              }
            />
          )}
          </motion.section>
        )}
        
        
      </main>
    </div>
  );
}
