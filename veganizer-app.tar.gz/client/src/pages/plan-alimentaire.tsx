import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Calendar, ChefHat, Trash2, Edit, Heart, AlertTriangle, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { type Menu, type MenuItem, type Favorite, type RecipeConversionResponse } from "@shared/schema";
import NutritionDashboard from "@/components/NutritionDashboard";

const menuFormSchema = z.object({
  name: z.string().min(1, "Le nom est obligatoire").max(100, "Nom trop long"),
  description: z.string().optional(),
});

const menuItemFormSchema = z.object({
  favorite_id: z.string().min(1, "Sélectionner une recette favorite"),
  day_of_week: z.string().optional(),
  servings: z.number().min(0.1).max(10).default(1),
});

const daysOfWeek = [
  { value: 'lundi', label: 'Lundi' },
  { value: 'mardi', label: 'Mardi' },
  { value: 'mercredi', label: 'Mercredi' },
  { value: 'jeudi', label: 'Jeudi' },
  { value: 'vendredi', label: 'Vendredi' },
  { value: 'samedi', label: 'Samedi' },
  { value: 'dimanche', label: 'Dimanche' },
];

export default function PlanAlimentaire() {
  const { toast } = useToast();
  const [selectedMenu, setSelectedMenu] = useState<Menu | null>(null);
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [editingMenu, setEditingMenu] = useState<Menu | null>(null);

  // Fetch user's menus
  const { data: menus = [], isLoading: isLoadingMenus, isError: menusError, refetch: refetchMenus } = useQuery<Menu[]>({
    queryKey: ['/api/menus'],
  });

  // Fetch user's favorites for adding to menus
  const { data: favorites = [], isLoading: isLoadingFavorites, isError: favoritesError } = useQuery<Favorite[]>({
    queryKey: ['/api/favorites'],
  });

  // Fetch all menu items for user across all menus
  const { data: allMenuItems = [], isLoading: isLoadingMenuItems, isError: menuItemsError } = useQuery<MenuItem[]>({
    queryKey: ['/api/menu-items'],
  });

  // Fetch menu items for selected menu (for display purposes)
  const { data: selectedMenuItems = [] } = useQuery<MenuItem[]>({
    queryKey: ['/api/menus', selectedMenu?.id, 'items'],
    enabled: !!selectedMenu,
  });


  // Update menu mutation
  const updateMenuMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<z.infer<typeof menuFormSchema>> }) => {
      const response = await apiRequest('PUT', `/api/menus/${id}`, data);
      return response.json();
    },
    onMutate: async ({ id, data }) => {
      // Optimistic update
      await queryClient.cancelQueries({ queryKey: ['/api/menus'] });
      const previousMenus = queryClient.getQueryData(['/api/menus']);
      
      queryClient.setQueryData(['/api/menus'], (old: Menu[] = []) => 
        old.map(menu => menu.id === id ? { ...menu, ...data } : menu)
      );
      
      return { previousMenus };
    },
    onSuccess: (updatedMenu) => {
      queryClient.invalidateQueries({ queryKey: ['/api/menus'] });
      setEditingMenu(null);
      editForm.reset();
      // Update selected menu if it's the one being edited
      if (selectedMenu?.id === updatedMenu.id) {
        setSelectedMenu(updatedMenu);
      }
      toast({ title: "Menu mis à jour avec succès!" });
    },
    onError: (error: any, variables, context) => {
      // Rollback optimistic update
      if (context?.previousMenus) {
        queryClient.setQueryData(['/api/menus'], context.previousMenus);
      }
      console.error('Menu update error:', error);
      toast({ 
        title: "Erreur lors de la mise à jour du menu",
        description: error?.message || "Veuillez réessayer plus tard", 
        variant: "destructive" 
      });
    },
  });

  // Delete menu mutation
  const deleteMenuMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/menus/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/menus'] });
      setSelectedMenu(null);
      toast({ title: "Menu supprimé avec succès!" });
    },
    onError: () => {
      toast({ title: "Erreur lors de la suppression du menu", variant: "destructive" });
    },
  });

  // Add item to menu mutation

  const addItemMutation = useMutation({
    mutationFn: async (data: z.infer<typeof menuItemFormSchema>) => {
      if (!selectedMenu) throw new Error("No menu selected");
      const response = await apiRequest('POST', `/api/menus/${selectedMenu.id}/items-from-favorite`, data);
      return response.json();
    },
    onSuccess: () => {
      const menuId = selectedMenu?.id;
      if (menuId) {
        queryClient.invalidateQueries({ queryKey: ['/api/menus', menuId, 'items'] });
        queryClient.invalidateQueries({ queryKey: ['/api/menu-items'] });
      }
      setIsAddItemOpen(false);
      itemForm.reset();
      toast({ title: "Recette favorite ajoutée au menu!" });
    },
    onError: () => {
      toast({ title: "Erreur lors de l'ajout de la recette favorite", variant: "destructive" });
    },
  });

  // Delete menu item mutation
  const deleteItemMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/menu-items/${id}`);
    },
    onSuccess: () => {
      const menuId = selectedMenu?.id;
      if (menuId) {
        queryClient.invalidateQueries({ queryKey: ['/api/menus', menuId, 'items'] });
      }
      toast({ title: "Recette supprimée du menu!" });
    },
    onError: (error: any) => {
      console.error('Item deletion error:', error);
      toast({ 
        title: "Erreur lors de la suppression",
        description: error?.message || "Veuillez réessayer plus tard",
        variant: "destructive" 
      });
    },
  });

  const editForm = useForm<z.infer<typeof menuFormSchema>>({
    resolver: zodResolver(menuFormSchema),
    defaultValues: { name: "", description: "" },
  });

  const itemForm = useForm<z.infer<typeof menuItemFormSchema>>({
    resolver: zodResolver(menuItemFormSchema),
    defaultValues: { favorite_id: "", day_of_week: undefined, servings: 1 },
  });


  const onUpdateMenu = async (data: z.infer<typeof menuFormSchema>) => {
    if (!editingMenu) return;
    updateMenuMutation.mutate({ id: editingMenu.id, data });
  };

  // Convert recipe and add to favorites mutation
  const convertAndAddToFavoritesMutation = useMutation({
    mutationFn: async (recipeName: string) => {
      // First convert the recipe
      const convertResponse = await apiRequest('POST', '/api/recipes/convert', { recipeName });
      const conversionResult = await convertResponse.json();
      
      // Then add to favorites
      const favoriteData = {
        recipe_name: conversionResult.originalRecipe.name,
        vegan_recipe_name: conversionResult.veganRecipe.name,
        recipe_data: JSON.stringify(conversionResult),
      };
      
      const favResponse = await apiRequest('POST', '/api/favorites', favoriteData);
      return favResponse.json();
    },
    onSuccess: (newFavorite) => {
      // Invalidate favorites cache
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
      
      // Recipe converted to favorite successfully  
      toast({ title: "Recette convertie et ajoutée à 'Mes Recettes'!" });
    },
    onError: (error: any) => {
      console.error("Error converting recipe:", error);
      toast({ 
        title: "Erreur lors de la conversion", 
        description: "Impossible de convertir la recette. Veuillez réessayer.",
        variant: "destructive" 
      });
    },
  });

  const onAddItem = async (data: z.infer<typeof menuItemFormSchema>) => {
    if (!selectedMenu || !data.favorite_id) return;
    
    // Use the new favorites endpoint that directly adds favorite to menu
    addItemMutation.mutate(data);
  };

  const handleEditMenu = (menu: Menu) => {
    setEditingMenu(menu);
    editForm.reset({ name: menu.name, description: menu.description || "" });
  };

  const getFavoriteById = (id: string) => favorites.find(f => f.id === id);

  // Group menu items by day of week for calendar view
  const menuItemsByDay = selectedMenuItems.reduce((acc, item) => {
    const day = item.day_of_week || 'unassigned';
    if (!acc[day]) {
      acc[day] = [];
    }
    acc[day].push(item);
    return acc;
  }, {} as Record<string, MenuItem[]>);

  // TODO: Quick add functionality to be re-implemented with new architecture
  const quickAddToDay = (favoriteId: string, dayOfWeek: string) => {
    // Temporarily disabled - needs separate endpoint for adding existing favorites
    console.log('Quick add temporarily disabled', { favoriteId, dayOfWeek });
    toast({ 
      title: "Fonctionnalité temporairement désactivée", 
      description: "Utilisez le bouton 'Ajouter une recette' pour le moment"
    });
  };

  if (isLoadingMenus) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-sm text-muted-foreground">Chargement de vos menus...</p>
        </div>
      </div>
    );
  }

  if (menusError) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <AlertTriangle className="w-16 h-16 mx-auto text-destructive opacity-50" />
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-2">Erreur de chargement</h2>
            <p className="text-muted-foreground mb-4">Impossible de charger vos menus</p>
            <Button 
              onClick={() => refetchMenus()}
              variant="outline"
              data-testid="button-retry-menus"
            >
              Réessayer
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <main id="main-content" className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-foreground mb-2" data-testid="text-page-title">
                Mon Plan Alimentaire
              </h1>
              <p className="text-muted-foreground text-lg">
                Gérez vos menus personnalisés avec vos recettes veganes favorites
              </p>
            </div>
          </div>
        </div>

        {/* Nutrition Dashboard */}
        {(favorites && favorites.length > 0) || (allMenuItems && allMenuItems.length > 0) ? (
          <NutritionDashboard favorites={favorites} menuItems={allMenuItems} />
        ) : null}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Menu List */}
          <div className="lg:col-span-1">
            <Card data-variant="elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Mes Menus ({menus.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {menus.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <ChefHat className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Menu en cours de création</p>
                    <p className="text-sm">Votre menu principal se crée automatiquement</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {menus.map((menu) => (
                      <Card
                        key={menu.id}
                        data-variant={selectedMenu?.id === menu.id ? "interactive" : "outline"}
                        className={`cursor-pointer transition-colors ${
                          selectedMenu?.id === menu.id
                            ? 'border-primary bg-primary/5'
                            : 'hover:border-primary/50'
                        }`}
                        onClick={() => setSelectedMenu(menu)}
                        data-testid={`menu-item-${menu.id}`}
                      >
                        <CardContent className="p-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-sm">{menu.name}</h3>
                            {menu.description && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {menu.description}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEditMenu(menu);
                              }}
                              data-testid={`button-edit-menu-${menu.id}`}
                            >
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteMenuMutation.mutate(menu.id);
                              }}
                              disabled={deleteMenuMutation.isPending}
                              data-testid={`button-delete-menu-${menu.id}`}
                            >
                              {deleteMenuMutation.isPending ? (
                                <div className="animate-spin rounded-full h-3 w-3 border border-destructive border-t-transparent" />
                              ) : (
                                <Trash2 className="w-3 h-3 text-destructive" />
                              )}
                            </Button>
                          </div>
                        </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Menu Details */}
          <div className="lg:col-span-2">
            {selectedMenu ? (
              <Card data-variant="elevated">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <ChefHat className="w-5 h-5" />
                        {selectedMenu.name}
                      </CardTitle>
                      {selectedMenu.description && (
                        <CardDescription className="mt-2">
                          {selectedMenu.description}
                        </CardDescription>
                      )}
                    </div>
                    <Dialog open={isAddItemOpen} onOpenChange={setIsAddItemOpen}>
                      <DialogTrigger asChild>
                        <Button size="sm" data-testid="button-add-recipe-to-menu">
                          <Plus className="w-4 h-4 mr-2" />
                          Ajouter une recette
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Ajouter une recette au menu</DialogTitle>
                          <DialogDescription>
                            Sélectionnez une recette de vos favoris pour l'ajouter au menu
                          </DialogDescription>
                        </DialogHeader>
                        <Form {...itemForm}>
                          <form onSubmit={itemForm.handleSubmit(onAddItem)} className="space-y-4">
                            <FormField
                              control={itemForm.control}
                              name="favorite_id"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Mes Recettes Favorites</FormLabel>
                                  {isLoadingFavorites ? (
                                    <div className="h-10 bg-muted/50 rounded border flex items-center justify-center text-sm text-muted-foreground">
                                      Chargement des favorites...
                                    </div>
                                  ) : !favorites || favorites.length === 0 ? (
                                    <div className="h-10 bg-muted/30 border rounded flex items-center justify-center text-sm text-muted-foreground">
                                      Aucune recette favorite. Convertissez d'abord des recettes.
                                    </div>
                                  ) : (
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                      <FormControl>
                                        <SelectTrigger data-testid="select-favorite">
                                          <SelectValue placeholder="Sélectionner une recette favorite" />
                                        </SelectTrigger>
                                      </FormControl>
                                      <SelectContent>
                                        {favorites.map((favorite) => (
                                          <SelectItem key={favorite.id} value={favorite.id}>
                                            <div className="flex flex-col items-start">
                                              <span className="font-medium">{favorite.vegan_recipe_name || favorite.recipe_name}</span>
                                              {favorite.vegan_recipe_name && favorite.recipe_name !== favorite.vegan_recipe_name && (
                                                <span className="text-sm text-gray-500">({favorite.recipe_name})</span>
                                              )}
                                            </div>
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  )}
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={itemForm.control}
                              name="day_of_week"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Jour de la semaine (optionnel)</FormLabel>
                                  <Select 
                                    onValueChange={(value) => field.onChange(value === "none" ? undefined : value)}
                                    defaultValue={field.value || "none"}
                                  >
                                    <FormControl>
                                      <SelectTrigger data-testid="select-day-of-week">
                                        <SelectValue placeholder="Choisir un jour" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="none">Aucun jour spécifique</SelectItem>
                                      {daysOfWeek.map((day) => (
                                        <SelectItem key={day.value} value={day.value}>
                                          {day.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={itemForm.control}
                              name="servings"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Nombre de portions</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      step="0.1"
                                      min="0.1"
                                      max="10"
                                      {...field} 
                                      onChange={(e) => field.onChange(e.target.valueAsNumber || 1)}
                                      data-testid="input-servings"
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <div className="flex justify-end space-x-2">
                              <Button 
                                type="button" 
                                variant="outline" 
                                onClick={() => setIsAddItemOpen(false)}
                              >
                                Annuler
                              </Button>
                              <Button 
                                type="submit" 
                                disabled={addItemMutation.isPending}
                                data-testid="button-save-menu-item"
                              >
                                {addItemMutation.isPending ? "Ajout..." : "Ajouter"}
                              </Button>
                            </div>
                          </form>
                        </Form>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoadingMenuItems ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                      <p className="text-muted-foreground">Chargement des recettes...</p>
                    </div>
                  ) : menuItemsError ? (
                    <div className="text-center py-8 text-destructive">
                      <ChefHat className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Erreur lors du chargement des recettes</p>
                      <p className="text-sm">Veuillez réessayer plus tard</p>
                    </div>
                  ) : selectedMenuItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Heart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Aucune recette dans ce menu</p>
                      <p className="text-sm">Ajoutez vos recettes favorites pour commencer</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {/* Weekly Calendar View */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {daysOfWeek.map((day) => {
                          const dayItems = menuItemsByDay[day.value] || [];
                          return (
                            <div key={day.value} className="border rounded-lg p-4 bg-card">
                              <div className="flex items-center justify-between mb-3">
                                <h4 className="font-semibold text-sm">{day.label}</h4>
                                <Badge variant="outline" className="text-xs">
                                  {dayItems.length}
                                </Badge>
                              </div>
                              
                              <div className="space-y-2 min-h-[100px]">
                                {dayItems.map((item) => {
                                  const favorite = getFavoriteById(item.favorite_id);
                                  if (!favorite) return null;
                                  
                                  return (
                                    <div
                                      key={item.id}
                                      className="p-2 bg-background rounded border text-xs"
                                      data-testid={`menu-recipe-${item.id}`}
                                    >
                                      <div className="flex justify-between items-start">
                                        <div className="flex-1 min-w-0">
                                          <p className="font-medium truncate">{favorite.vegan_recipe_name}</p>
                                          <p className="text-muted-foreground">{item.servings} portions</p>
                                        </div>
                                        <Button
                                          size="sm"
                                          variant="ghost"
                                          className="h-auto w-auto p-1 ml-1"
                                          onClick={() => deleteItemMutation.mutate(item.id)}
                                          data-testid={`button-remove-recipe-${item.id}`}
                                        >
                                          <Trash2 className="w-3 h-3 text-destructive" />
                                        </Button>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                              
                              {/* Quick add dropdown for this day */}
                              <div className="mt-3">
                                <Select onValueChange={(favoriteId) => {
                                  if (favoriteId) {
                                    quickAddToDay(favoriteId, day.value);
                                  }
                                }}>
                                  <SelectTrigger className="h-8 text-xs" data-testid={`select-quick-add-${day.value}`}>
                                    <SelectValue placeholder="+ Ajouter" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {favorites.map((favorite) => (
                                      <SelectItem key={favorite.id} value={favorite.id}>
                                        {favorite.vegan_recipe_name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      
                      {/* Unassigned items section */}
                      {menuItemsByDay.unassigned && menuItemsByDay.unassigned.length > 0 && (
                        <div className="border-t pt-4">
                          <h4 className="font-semibold mb-3 flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            Recettes sans jour assigné ({menuItemsByDay.unassigned.length})
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {menuItemsByDay.unassigned.map((item) => {
                              const favorite = getFavoriteById(item.favorite_id);
                              if (!favorite) return null;
                              
                              let recipeData: RecipeConversionResponse;
                              try {
                                recipeData = JSON.parse(favorite.recipe_data) as RecipeConversionResponse;
                              } catch (error) {
                                console.error("Failed to parse recipe data:", error);
                                return null;
                              }
                              
                              return (
                                <div
                                  key={item.id}
                                  className="flex justify-between items-center p-3 border rounded-lg bg-muted/30"
                                  data-testid={`menu-recipe-unassigned-${item.id}`}
                                >
                                  <div className="flex-1">
                                    <h5 className="font-medium text-sm">{favorite.vegan_recipe_name}</h5>
                                    <p className="text-xs text-muted-foreground">
                                      {recipeData.substitutionCount} substitutions • {item.servings} portions
                                    </p>
                                  </div>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => deleteItemMutation.mutate(item.id)}
                                    data-testid={`button-remove-recipe-${item.id}`}
                                  >
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-96">
                  <div className="text-center text-muted-foreground">
                    <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg">Sélectionnez un menu pour voir les détails</p>
                    <p className="text-sm">Ou créez votre premier menu pour commencer</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Edit Menu Dialog */}
        <Dialog open={!!editingMenu} onOpenChange={() => setEditingMenu(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Modifier le menu</DialogTitle>
              <DialogDescription>
                Modifiez les informations de votre menu
              </DialogDescription>
            </DialogHeader>
            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onUpdateMenu)} className="space-y-4">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nom du menu</FormLabel>
                      <FormControl>
                        <Input placeholder="ex: Menu de la semaine" {...field} data-testid="input-edit-menu-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (optionnel)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Décrivez votre menu..." 
                          {...field} 
                          data-testid="input-edit-menu-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setEditingMenu(null)}
                  >
                    Annuler
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={updateMenuMutation.isPending}
                    data-testid="button-update-menu"
                  >
                    {updateMenuMutation.isPending ? "Mise à jour..." : "Mettre à jour"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}