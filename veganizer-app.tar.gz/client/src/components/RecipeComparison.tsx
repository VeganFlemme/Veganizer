import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Users, Flame, Leaf, Utensils, Info, Plus, ExternalLink, Heart, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { type RecipeConversionResponse } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";

interface RecipeComparisonProps {
  originalRecipe: {
    name: string;
    ingredients: string[];
    cookingTime?: string;
    servings?: number;
    difficulty?: string;
  };
  veganRecipe: {
    name: string;
    ingredients: Array<{
      name: string;
      substitution?: string;
      isSubstituted: boolean;
    }>;
    cookingTime?: string;
    servings?: number;
    difficulty?: string;
  };
  substitutionCount: number;
  conversionResult: RecipeConversionResponse;
}


export default function RecipeComparison({ 
  originalRecipe, 
  veganRecipe, 
  substitutionCount,
  conversionResult 
}: RecipeComparisonProps) {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();

  const addToFavoritesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/favorites', {
        recipe_name: originalRecipe.name,
        vegan_recipe_name: veganRecipe.name,
        recipe_data: JSON.stringify(conversionResult),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Recette ajoutée !",
        description: `${veganRecipe.name} a été ajoutée à vos recettes favorites.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error?.message || "Impossible d'ajouter la recette aux favorites",
        variant: "destructive",
      });
    },
  });

  const handleAddToFavorites = () => {
    if (!isAuthenticated) {
      // Redirect to login if user is not authenticated
      window.location.href = '/api/login';
      return;
    }
    addToFavoritesMutation.mutate();
  };
  return (
    <section id="results-section" className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 mb-16 lg:mb-20">
      {/* Original Recipe Card */}
      <Card data-variant="elevated" className="group transition-all duration-200 hover:shadow-xl">
        <CardContent>
          <div className="flex items-start justify-between mb-6">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-foreground">Recette Originale</h3>
              <Badge variant="secondary" className="flex items-center gap-2 text-sm">
                <Utensils className="w-4 h-4" />
                Omnivore
              </Badge>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="text-xl font-semibold text-foreground mb-4" data-testid="text-original-recipe-name">
              {originalRecipe.name}
            </h4>
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <Badge variant="outline" className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {originalRecipe.cookingTime}
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                {originalRecipe.servings}p
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                {originalRecipe.difficulty}
              </Badge>
            </div>
          </div>

          <div>
            <h5 className="font-semibold text-foreground mb-4 text-lg">Ingrédients</h5>
            <div className="space-y-2">
              {originalRecipe.ingredients.map((ingredient, index) => (
                <div 
                  key={index}
                  className="flex items-center p-3 bg-muted/30 rounded-lg border border-border/50"
                  data-testid={`original-ingredient-${index}`}
                >
                  <div className="w-2 h-2 bg-muted-foreground rounded-full mr-3 flex-shrink-0" />
                  <span className="text-foreground text-sm leading-relaxed">{ingredient}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vegan Recipe Card */}
      <Card data-variant="elevated" className="group transition-all duration-200 hover:shadow-xl border-primary/20">
        <CardContent>
          <div className="flex items-start justify-between mb-6">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-foreground">Version Végane</h3>
              <Badge className="flex items-center gap-2 text-sm bg-primary text-primary-foreground">
                <Leaf className="w-4 h-4" />
                100% Végane
              </Badge>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="text-xl font-semibold text-foreground mb-4" data-testid="text-vegan-recipe-name">
              {veganRecipe.name}
            </h4>
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <Badge variant="outline" className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {veganRecipe.cookingTime}
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                {veganRecipe.servings}p
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                {veganRecipe.difficulty}
              </Badge>
              <Badge variant="default" className="flex items-center gap-1.5 bg-primary/10 text-primary border-primary/20">
                <Info className="w-3.5 h-3.5" />
                <span data-testid="text-substitution-count">{substitutionCount}</span> substitutions
              </Badge>
            </div>
            
            <Button 
              onClick={handleAddToFavorites}
              disabled={addToFavoritesMutation.isPending}
              className="w-full mb-4 flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
              data-testid="button-add-to-favorites"
            >
              <Plus className="w-4 h-4" />
              {addToFavoritesMutation.isPending ? "Ajout..." : "Ajouter aux favoris"}
            </Button>
          </div>

          <div>
            <h5 className="font-semibold text-foreground mb-4 text-lg">Ingrédients véganes</h5>
            <div className="space-y-3">
              {veganRecipe.ingredients.map((ingredient, index) => (
                <div 
                  key={index}
                  data-testid={`vegan-ingredient-${index}`}
                >
                  {ingredient.isSubstituted && ingredient.substitution ? (
                    <div className="p-4 bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg border border-primary/20 transition-all duration-200 hover:shadow-md">
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                            <span className="text-foreground font-medium">
                              {ingredient.name}
                            </span>
                            {ingredient.name.toLowerCase().includes('seitan') && (
                              <a 
                                href="https://amzn.to/4nnhpBi" 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                                data-testid="seitan-amazon-link"
                              >
                                <ExternalLink className="w-3 h-3" />
                                Amazon
                              </a>
                            )}
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            Substitution
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Remplace <span className="font-medium">{ingredient.substitution}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center p-3 bg-muted/30 rounded-lg border border-border/50">
                      <div className="w-2 h-2 bg-primary rounded-full mr-3 flex-shrink-0" />
                      <span className="flex-1 text-foreground text-sm">{ingredient.name}</span>
                      <Badge variant="default" className="text-xs bg-primary/10 text-primary">✓ Végane</Badge>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </CardContent>
      </Card>
    </section>
  );
}
