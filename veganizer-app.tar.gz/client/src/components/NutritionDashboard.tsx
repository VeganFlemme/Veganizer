import { useState, useEffect, useRef, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, AlertTriangle, BarChart3, Heart, ExternalLink, Loader2 } from "lucide-react";
import { type Favorite, type MenuItem, type RecipeConversionResponse, recipeConversionResponseSchema, type supplements } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

// Chart.js interface for type safety
interface ChartInstance {
  data: {
    datasets: {
      data: number[];
    }[];
  };
  update: (mode?: string) => void;
  destroy: () => void;
}

interface NutritionDashboardProps {
  favorites: Favorite[];
  menuItems?: MenuItem[];
}

interface AverageNutrition {
  calories: number;
  proteins: number;
  carbs: number;
  fats: number;
  fiber: number;
  calcium: number;
  iron: number;
  zinc: number;
}

interface Supplement {
  id: string;
  name: string;
  type: string;
  priority: string;
  serving_size: string;
  amazon_link: string;
  description?: string | null;
  reason?: string; // Custom reason for recommendation
}

interface ClimateImpactTotals {
  totalCO2Reduction: number;
  totalWaterSaving: number;
  totalLandSaving: number;
  originalTotals: {
    co2: number;
    water: number;
    land: number;
  };
  veganTotals: {
    co2: number;
    water: number;
    land: number;
  };
  averageReductionPercentages: {
    co2: number;
    water: number;
    land: number;
  };
}

interface AnimalSavingsTotals {
  totalAnimals: number;
  totalLifeYearsSaved: number;
  animalBreakdown: {
    cows: number;
    pigs: number;
    chickens: number;
    fish: number;
    dairy_cows: number;
    hens: number;
  };
}

export default function NutritionDashboard({ favorites, menuItems }: NutritionDashboardProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<ChartInstance | null>(null);
  const chartClassRef = useRef<any>(null);
  const [showFullDashboard, setShowFullDashboard] = useState(false);
  const [isChartLoading, setIsChartLoading] = useState(false);

  // Fetch supplements from database
  const { data: supplementsData, isLoading: supplementsLoading } = useQuery<{success: boolean, data: (typeof supplements.$inferSelect)[]}>({
    queryKey: ['/api/supplements'],
    queryFn: async () => {
      const response = await fetch('/api/supplements');
      if (!response.ok) {
        throw new Error('Failed to fetch supplements');
      }
      return response.json();
    },
  });

  // Calculate average nutrition from all favorite recipes (memoized)
  const averageNutrition = useMemo((): AverageNutrition => {
    if (!favorites || favorites.length === 0) {
      return {
        calories: 0,
        proteins: 0,
        carbs: 0,
        fats: 0,
        fiber: 0,
        calcium: 0,
        iron: 0,
        zinc: 0,
      };
    }

    let validRecipeCount = 0;
    const totals = favorites.reduce(
      (acc, favorite) => {
        try {
          const parsedData = JSON.parse(favorite.recipe_data);
          const validationResult = recipeConversionResponseSchema.safeParse(parsedData);
          
          if (!validationResult.success) {
            console.warn('Skipping invalid recipe data:', validationResult.error.errors);
            return acc;
          }
          
          const recipeData = validationResult.data;
          const nutrition = recipeData.nutritionComparison.vegan;
          
          // Only increment count after successful validation and field access
          const updatedTotals = {
            calories: acc.calories + nutrition.calories,
            proteins: acc.proteins + nutrition.proteins,
            carbs: acc.carbs + nutrition.carbs,
            fats: acc.fats + nutrition.fats,
            fiber: acc.fiber + nutrition.fiber,
            calcium: acc.calcium + nutrition.calcium,
            iron: acc.iron + nutrition.iron,
            zinc: acc.zinc + nutrition.zinc,
          };
          
          validRecipeCount++;
          return updatedTotals;
        } catch (error) {
          console.warn('Skipping malformed recipe data:', error);
          return acc;
        }
      },
      {
        calories: 0,
        proteins: 0,
        carbs: 0,
        fats: 0,
        fiber: 0,
        calcium: 0,
        iron: 0,
        zinc: 0,
      }
    );

    // If no valid recipes, return zeros
    if (validRecipeCount === 0) {
      return {
        calories: 0,
        proteins: 0,
        carbs: 0,
        fats: 0,
        fiber: 0,
        calcium: 0,
        iron: 0,
        zinc: 0,
      };
    }

    return {
      calories: Math.round(totals.calories / validRecipeCount),
      proteins: Math.round((totals.proteins / validRecipeCount) * 10) / 10,
      carbs: Math.round((totals.carbs / validRecipeCount) * 10) / 10,
      fats: Math.round((totals.fats / validRecipeCount) * 10) / 10,
      fiber: Math.round((totals.fiber / validRecipeCount) * 10) / 10,
      calcium: Math.round(totals.calcium / validRecipeCount),
      iron: Math.round((totals.iron / validRecipeCount) * 10) / 10,
      zinc: Math.round((totals.zinc / validRecipeCount) * 10) / 10,
    };
  }, [favorites]);

  // Calculate aggregated climate impact across all favorite recipes (memoized)
  const climateImpactTotals = useMemo((): ClimateImpactTotals => {
    if (!favorites || favorites.length === 0) {
      return {
        totalCO2Reduction: 0,
        totalWaterSaving: 0,
        totalLandSaving: 0,
        originalTotals: { co2: 0, water: 0, land: 0 },
        veganTotals: { co2: 0, water: 0, land: 0 },
        averageReductionPercentages: { co2: 0, water: 0, land: 0 },
      };
    }

    let validRecipeCount = 0;
    const totals = favorites.reduce(
      (acc, favorite) => {
        try {
          const parsedData = JSON.parse(favorite.recipe_data);
          const validationResult = recipeConversionResponseSchema.safeParse(parsedData);
          
          if (!validationResult.success) {
            console.warn('Skipping invalid climate data:', validationResult.error.errors);
            return acc;
          }
          
          const recipeData = validationResult.data;
          const climate = recipeData.climateComparison;
          
          // Only increment count after successful validation and field access
          const updatedTotals = {
            originalCO2: acc.originalCO2 + climate.details.original.totalCO2,
            originalWater: acc.originalWater + climate.details.original.totalWater,
            originalLand: acc.originalLand + climate.details.original.totalLand,
            veganCO2: acc.veganCO2 + climate.details.vegan.totalCO2,
            veganWater: acc.veganWater + climate.details.vegan.totalWater,
            veganLand: acc.veganLand + climate.details.vegan.totalLand,
            percentageCO2: acc.percentageCO2 + climate.co2Reduction,
            percentageWater: acc.percentageWater + climate.waterSaving,
            percentageLand: acc.percentageLand + climate.landSaving,
          };
          
          validRecipeCount++;
          return updatedTotals;
        } catch (error) {
          console.warn('Skipping malformed climate data:', error);
          return acc;
        }
      },
      {
        originalCO2: 0,
        originalWater: 0,
        originalLand: 0,
        veganCO2: 0,
        veganWater: 0,
        veganLand: 0,
        percentageCO2: 0,
        percentageWater: 0,
        percentageLand: 0,
      }
    );

    if (validRecipeCount === 0) {
      return {
        totalCO2Reduction: 0,
        totalWaterSaving: 0,
        totalLandSaving: 0,
        originalTotals: { co2: 0, water: 0, land: 0 },
        veganTotals: { co2: 0, water: 0, land: 0 },
        averageReductionPercentages: { co2: 0, water: 0, land: 0 },
      };
    }

    return {
      totalCO2Reduction: Math.round((totals.originalCO2 - totals.veganCO2) * 100) / 100,
      totalWaterSaving: Math.round((totals.originalWater - totals.veganWater) * 100) / 100,
      totalLandSaving: Math.round((totals.originalLand - totals.veganLand) * 100) / 100,
      originalTotals: {
        co2: Math.round(totals.originalCO2 * 100) / 100,
        water: Math.round(totals.originalWater * 100) / 100,
        land: Math.round(totals.originalLand * 100) / 100,
      },
      veganTotals: {
        co2: Math.round(totals.veganCO2 * 100) / 100,
        water: Math.round(totals.veganWater * 100) / 100,
        land: Math.round(totals.veganLand * 100) / 100,
      },
      averageReductionPercentages: {
        co2: Math.round((totals.percentageCO2 / validRecipeCount) * 10) / 10,
        water: Math.round((totals.percentageWater / validRecipeCount) * 10) / 10,
        land: Math.round((totals.percentageLand / validRecipeCount) * 10) / 10,
      },
    };
  }, [favorites]);

  // Calculate aggregated animal savings across menu items (memoized)
  const animalSavingsTotals = useMemo((): AnimalSavingsTotals => {
    // Use menuItems if available, fall back to favorites for backwards compatibility
    const dataSource = menuItems && menuItems.length > 0 ? menuItems : undefined;
    
    if (!dataSource && (!favorites || favorites.length === 0)) {
      return {
        totalAnimals: 0,
        totalLifeYearsSaved: 0,
        animalBreakdown: {
          cows: 0,
          pigs: 0,
          chickens: 0,
          fish: 0,
          dairy_cows: 0,
          hens: 0,
        },
      };
    }

    let validRecipeCount = 0;
    const totals = dataSource ? 
      // Calculate from menu items (weighted by servings)
      dataSource.reduce(
        (acc, menuItem) => {
          try {
            // Find the corresponding favorite
            const favorite = favorites.find(f => f.id === menuItem.favorite_id);
            if (!favorite) {
              console.warn('Favorite not found for menu item:', menuItem.favorite_id);
              return acc;
            }

            const parsedData = JSON.parse(favorite.recipe_data);
            const validationResult = recipeConversionResponseSchema.safeParse(parsedData);
            
            if (!validationResult.success) {
              console.warn('Skipping invalid animal savings data:', validationResult.error.errors);
              return acc;
            }
            
            const recipeData = validationResult.data;
            const animalSavings = recipeData.animalSavings;
            
            if (!animalSavings || !animalSavings.animalBreakdown) {
              return acc;
            }
            
            // Weight by servings from menu item
            const servings = menuItem.servings || 1;
            
            const updatedTotals = {
              totalAnimals: acc.totalAnimals + (animalSavings.totalAnimals || 0) * servings,
              totalLifeYearsSaved: acc.totalLifeYearsSaved + (animalSavings.lifeYearsSaved || 0) * servings,
              cows: acc.cows + (animalSavings.animalBreakdown.cows || 0) * servings,
              pigs: acc.pigs + (animalSavings.animalBreakdown.pigs || 0) * servings,
              chickens: acc.chickens + (animalSavings.animalBreakdown.chickens || 0) * servings,
              fish: acc.fish + (animalSavings.animalBreakdown.fish || 0) * servings,
              dairy_cows: acc.dairy_cows + (animalSavings.animalBreakdown.dairy_cows || 0) * servings,
              hens: acc.hens + (animalSavings.animalBreakdown.hens || 0) * servings,
            };
            
            validRecipeCount++;
            return updatedTotals;
          } catch (error) {
            console.warn('Skipping malformed animal savings data:', error);
            return acc;
          }
        },
        {
          totalAnimals: 0,
          totalLifeYearsSaved: 0,
          cows: 0,
          pigs: 0,
          chickens: 0,
          fish: 0,
          dairy_cows: 0,
          hens: 0,
        }
      )
      :
      // Fallback: calculate from favorites (backwards compatibility)
      favorites.reduce(
        (acc, favorite) => {
          try {
            const parsedData = JSON.parse(favorite.recipe_data);
            const validationResult = recipeConversionResponseSchema.safeParse(parsedData);
            
            if (!validationResult.success) {
              console.warn('Skipping invalid animal savings data:', validationResult.error.errors);
              return acc;
            }
            
            const recipeData = validationResult.data;
            const animalSavings = recipeData.animalSavings;
            
            if (!animalSavings || !animalSavings.animalBreakdown) {
              return acc;
            }
            
            const updatedTotals = {
              totalAnimals: acc.totalAnimals + (animalSavings.totalAnimals || 0),
              totalLifeYearsSaved: acc.totalLifeYearsSaved + (animalSavings.lifeYearsSaved || 0),
              cows: acc.cows + (animalSavings.animalBreakdown.cows || 0),
              pigs: acc.pigs + (animalSavings.animalBreakdown.pigs || 0),
              chickens: acc.chickens + (animalSavings.animalBreakdown.chickens || 0),
              fish: acc.fish + (animalSavings.animalBreakdown.fish || 0),
              dairy_cows: acc.dairy_cows + (animalSavings.animalBreakdown.dairy_cows || 0),
              hens: acc.hens + (animalSavings.animalBreakdown.hens || 0),
            };
            
            validRecipeCount++;
            return updatedTotals;
          } catch (error) {
            console.warn('Skipping malformed animal savings data:', error);
            return acc;
          }
        },
        {
          totalAnimals: 0,
          totalLifeYearsSaved: 0,
          cows: 0,
          pigs: 0,
          chickens: 0,
          fish: 0,
          dairy_cows: 0,
          hens: 0,
        }
      );

    if (validRecipeCount === 0) {
      return {
        totalAnimals: 0,
        totalLifeYearsSaved: 0,
        animalBreakdown: {
          cows: 0,
          pigs: 0,
          chickens: 0,
          fish: 0,
          dairy_cows: 0,
          hens: 0,
        },
      };
    }

    return {
      totalAnimals: Math.round(totals.totalAnimals * 100) / 100,
      totalLifeYearsSaved: Math.round(totals.totalLifeYearsSaved * 100) / 100,
      animalBreakdown: {
        cows: Math.round(totals.cows * 100) / 100,
        pigs: Math.round(totals.pigs * 100) / 100,
        chickens: Math.round(totals.chickens * 100) / 100,
        fish: Math.round(totals.fish * 100) / 100,
        dairy_cows: Math.round(totals.dairy_cows * 100) / 100,
        hens: Math.round(totals.hens * 100) / 100,
      },
    };
  }, [favorites, menuItems]);

  // Global supplement recommendation system using database supplements
  const detectGlobalDeficiencies = (avgNutrition: AverageNutrition, hasValidData: boolean): Supplement[] => {
    const recommendedSupplements: Supplement[] = [];
    
    // Only show supplements if we have valid nutritional data and supplements are loaded
    if (!hasValidData || !supplementsData?.success || !supplementsData.data) {
      return recommendedSupplements;
    }

    const dbSupplements = supplementsData.data;
    
    // Helper function to find supplement by name
    const findSupplement = (name: string) => 
      dbSupplements.find(s => s.name.toLowerCase().includes(name.toLowerCase()));

    // Always include B12 and Omega-3 for vegans when we have data
    const b12Supplement = findSupplement("Vitamine B12 Vegan");
    if (b12Supplement) {
      recommendedSupplements.push({
        ...b12Supplement,
        reason: "Essentiel pour l'alimentation végane"
      });
    }

    const omega3Supplement = findSupplement("Omega 3 Vegan");
    if (omega3Supplement) {
      recommendedSupplements.push({
        ...omega3Supplement,
        reason: "Acides gras essentiels végans"
      });
    }

    // Iron deficiency detection (average per meal)
    if (avgNutrition.iron < 6) {
      const ironSupplement = findSupplement("Fer bisglycinate");
      if (ironSupplement) {
        recommendedSupplements.push({
          ...ironSupplement,
          reason: `Fer moyen ${avgNutrition.iron}mg/recette (recommandé: 6-8mg)`
        });
      }
    }

    // Zinc deficiency detection
    if (avgNutrition.zinc < 6) {
      const zincSupplement = findSupplement("Zinc bisglycinate");
      if (zincSupplement) {
        recommendedSupplements.push({
          ...zincSupplement,
          reason: `Zinc moyen ${avgNutrition.zinc}mg/recette (recommandé: 6-8mg)`
        });
      }
    }

    // Calcium deficiency detection
    if (avgNutrition.calcium < 350) {
      const calciumSupplement = findSupplement("Calcium + Vitamine D3");
      if (calciumSupplement) {
        recommendedSupplements.push({
          ...calciumSupplement,
          reason: `Calcium moyen ${avgNutrition.calcium}mg/recette (recommandé: 350-500mg)`
        });
      }
    }

    // Protein adequacy check
    if (avgNutrition.proteins < 15) {
      const proteinSupplement = findSupplement("Spiruline");
      if (proteinSupplement) {
        recommendedSupplements.push({
          ...proteinSupplement,
          reason: `Protéines moyennes ${avgNutrition.proteins}g/recette (recommandé: 15-20g)`
        });
      }
    }

    return recommendedSupplements;
  };

  const recommendedSupplements = useMemo(() => {
    // Check if we have valid nutritional data (not all zeros)
    const hasValidData = favorites && favorites.length > 0 && (
      averageNutrition.calories > 0 ||
      averageNutrition.proteins > 0 ||
      averageNutrition.carbs > 0 ||
      averageNutrition.fats > 0 ||
      averageNutrition.fiber > 0 ||
      averageNutrition.calcium > 0 ||
      averageNutrition.iron > 0 ||
      averageNutrition.zinc > 0
    );
    
    return detectGlobalDeficiencies(averageNutrition, hasValidData);
  }, [averageNutrition, favorites, supplementsData]);

  // Lazy load Chart.js only when needed (cached)
  const loadChartJs = async () => {
    if (chartClassRef.current) {
      return chartClassRef.current;
    }
    
    setIsChartLoading(true);
    try {
      const { Chart, registerables } = await import('chart.js');
      Chart.register(...registerables);
      chartClassRef.current = Chart;
      return Chart;
    } catch (error) {
      console.error('Failed to load Chart.js:', error);
      throw error;
    } finally {
      setIsChartLoading(false);
    }
  };

  // Chart creation/teardown effect - based on dashboard visibility
  useEffect(() => {
    if (!chartRef.current || !showFullDashboard) {
      return;
    }

    // Only create chart if it doesn't exist
    if (chartInstance.current) {
      return;
    }

    const createChart = async () => {
      try {
        const ChartClass = await loadChartJs();
        if (!ChartClass) {
          console.error('Chart.js failed to load');
          return;
        }
        
        // Get context after Chart.js is loaded to avoid stale references
        if (!chartRef.current) {
          console.warn('Canvas ref became null during Chart.js loading');
          return;
        }
        
        const ctx = chartRef.current.getContext('2d');
        if (!ctx) {
          console.warn('Failed to get canvas context');
          return;
        }
        
        // Double-check that chart instance is still null (avoid race conditions)
        if (chartInstance.current) {
          console.warn('Chart instance already exists, skipping creation');
          return;
        }
        
        chartInstance.current = new ChartClass(ctx, {
          type: 'bar',
          data: {
            labels: ['Protéines (g)', 'Fibres (g)', 'Calcium (mg)', 'Fer (mg)', 'Zinc (mg)'],
            datasets: [{
              label: 'Valeur par recette',
              data: [
                averageNutrition.proteins,
                averageNutrition.fiber,
                averageNutrition.calcium,
                averageNutrition.iron,
                averageNutrition.zinc,
              ],
              backgroundColor: 'rgba(16, 185, 129, 0.8)',
              borderColor: 'rgba(16, 185, 129, 1)',
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  display: true
                }
              }
            },
            plugins: {
              legend: {
                display: false
              }
            }
          }
        });
      } catch (error) {
        console.error('Failed to initialize chart:', error);
      }
    };

    createChart();

    return () => {
      // Always destroy on cleanup to prevent memory leaks
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [showFullDashboard]);

  // Chart data update effect - based on nutrition changes
  useEffect(() => {
    if (chartInstance.current && showFullDashboard) {
      // Update existing chart data without recreation (only when dashboard is visible)
      chartInstance.current.data.datasets[0].data = [
        averageNutrition.proteins,
        averageNutrition.fiber,
        averageNutrition.calcium,
        averageNutrition.iron,
        averageNutrition.zinc,
      ];
      chartInstance.current.update('none'); // Update without animation for performance
    }
  }, [averageNutrition, showFullDashboard]);

  return (
    <Card data-variant="elevated" className="mb-8">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BarChart3 className="w-6 h-6 text-primary" />
            <span>Synthèse Nutritionnelle</span>
            <Badge variant="outline">
              {favorites.length} recettes
            </Badge>
          </div>
          <Button 
            variant="outline"
            onClick={() => setShowFullDashboard(!showFullDashboard)}
            className="flex items-center gap-2"
            data-testid="button-toggle-nutrition-dashboard"
          >
            {showFullDashboard ? "Réduire" : "Détails"}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>

      {/* Quick Summary */}
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <Card data-variant="outline" className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-foreground">{averageNutrition.calories}</div>
            <div className="text-sm text-muted-foreground">kcal/recette</div>
          </CardContent>
        </Card>
        <Card data-variant="outline" className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-foreground">{averageNutrition.proteins}g</div>
            <div className="text-sm text-muted-foreground">Protéines</div>
          </CardContent>
        </Card>
        <Card data-variant="outline" className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-foreground">{averageNutrition.fiber}g</div>
            <div className="text-sm text-muted-foreground">Fibres</div>
          </CardContent>
        </Card>
        <Card data-variant="outline" className="text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-foreground">{favorites.length}</div>
            <div className="text-sm text-muted-foreground">Recettes</div>
          </CardContent>
        </Card>
      </div>

      {/* Expanded Dashboard */}
      {showFullDashboard && (
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Nutrition Chart */}
          <div>
            <h4 className="font-semibold text-foreground mb-3">Profil Nutritionnel Moyen</h4>
            <div style={{ height: '300px', position: 'relative' }} className="bg-muted/10 rounded-lg">
              <canvas 
                ref={chartRef} 
                data-testid="chart-nutrition-dashboard"
                style={{ position: 'absolute', inset: 0 }}
              />
              {isChartLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-muted/90 rounded-lg">
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Loader2 className="w-8 h-8 animate-spin" />
                    <span className="text-sm">Chargement du graphique...</span>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Detailed Nutrition Summary */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground mb-3">Détails par Recette (moyenne)</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-muted/10 rounded-lg">
                <span className="text-muted-foreground">Calcium</span>
                <span className="font-semibold text-foreground">{averageNutrition.calcium}mg</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/10 rounded-lg">
                <span className="text-muted-foreground">Fer</span>
                <span className="font-semibold text-foreground">{averageNutrition.iron}mg</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/10 rounded-lg">
                <span className="text-muted-foreground">Zinc</span>
                <span className="font-semibold text-foreground">{averageNutrition.zinc}mg</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/10 rounded-lg">
                <span className="text-muted-foreground">Glucides</span>
                <span className="font-semibold text-foreground">{averageNutrition.carbs}g</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/10 rounded-lg">
                <span className="text-muted-foreground">Lipides</span>
                <span className="font-semibold text-foreground">{averageNutrition.fats}g</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Climate Impact Aggregation */}
      {favorites && favorites.length > 0 && (
        <div className="mt-8 pt-6 border-t border-border">
          <div className="bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-800/30 rounded-lg p-6">
            <h4 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Impact Environnemental de Votre Plan Alimentaire
            </h4>
            
            <p className="text-sm text-muted-foreground mb-6">
              Réductions totales obtenues par vos {favorites.length} recettes véganes favorites
            </p>

            {/* Summary Cards */}
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <Card data-variant="outline" className="text-center">
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-600">
                    {climateImpactTotals.totalCO2Reduction.toFixed(2)}kg
                  </div>
                  <div className="text-sm text-muted-foreground">CO₂ évité</div>
                  <div className="text-xs text-green-600 mt-1">
                    -{climateImpactTotals.averageReductionPercentages.co2.toFixed(1)}% en moyenne
                  </div>
                </CardContent>
              </Card>
              
              <Card data-variant="outline" className="text-center">
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-blue-600">
                    {climateImpactTotals.totalWaterSaving.toFixed(0)}L
                  </div>
                  <div className="text-sm text-muted-foreground">Eau économisée</div>
                  <div className="text-xs text-blue-600 mt-1">
                    -{climateImpactTotals.averageReductionPercentages.water.toFixed(1)}% en moyenne
                  </div>
                </CardContent>
              </Card>
              
              <Card data-variant="outline" className="text-center">
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-amber-600">
                    {climateImpactTotals.totalLandSaving.toFixed(2)}m²
                  </div>
                  <div className="text-sm text-muted-foreground">Terres préservées</div>
                  <div className="text-xs text-amber-600 mt-1">
                    -{climateImpactTotals.averageReductionPercentages.land.toFixed(1)}% en moyenne
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Animal Savings Cards */}
            <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/10 border border-purple-200 dark:border-purple-800/30 rounded-lg">
              <h5 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                Animaux Sauvés par Votre Plan Alimentaire
              </h5>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg border">
                  <div className="text-2xl font-bold text-purple-600" data-testid="text-animals-saved-total">
                    {animalSavingsTotals.totalAnimals}
                  </div>
                  <div className="text-sm text-muted-foreground">Animaux sauvés</div>
                  <div className="text-xs text-purple-600 mt-1">
                    Grâce à vos choix végans
                  </div>
                </div>
                
                <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg border">
                  <div className="text-2xl font-bold text-purple-600" data-testid="text-life-years-saved">
                    {animalSavingsTotals.totalLifeYearsSaved}
                  </div>
                  <div className="text-sm text-muted-foreground">Années de vie sauvées</div>
                  <div className="text-xs text-purple-600 mt-1">
                    Impact sur le bien-être animal
                  </div>
                </div>
              </div>

              {/* Animal Breakdown */}
              {animalSavingsTotals.totalAnimals > 0 && (
                <div className="mt-4 p-3 bg-white dark:bg-gray-800 rounded-lg border">
                  <h6 className="text-sm font-medium text-muted-foreground mb-3">Répartition par type d'animal</h6>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                    {animalSavingsTotals.animalBreakdown.cows > 0 && (
                      <div className="flex justify-between" data-testid="text-cows-saved">
                        <span>🐄 Bovins:</span>
                        <span className="font-medium">{animalSavingsTotals.animalBreakdown.cows}</span>
                      </div>
                    )}
                    {animalSavingsTotals.animalBreakdown.pigs > 0 && (
                      <div className="flex justify-between" data-testid="text-pigs-saved">
                        <span>🐷 Cochons:</span>
                        <span className="font-medium">{animalSavingsTotals.animalBreakdown.pigs}</span>
                      </div>
                    )}
                    {animalSavingsTotals.animalBreakdown.chickens > 0 && (
                      <div className="flex justify-between" data-testid="text-chickens-saved">
                        <span>🐔 Poulets:</span>
                        <span className="font-medium">{animalSavingsTotals.animalBreakdown.chickens}</span>
                      </div>
                    )}
                    {animalSavingsTotals.animalBreakdown.fish > 0 && (
                      <div className="flex justify-between" data-testid="text-fish-saved">
                        <span>🐟 Poissons:</span>
                        <span className="font-medium">{animalSavingsTotals.animalBreakdown.fish}</span>
                      </div>
                    )}
                    {animalSavingsTotals.animalBreakdown.dairy_cows > 0 && (
                      <div className="flex justify-between" data-testid="text-dairy-cows-saved">
                        <span>🥛 Vaches laitières:</span>
                        <span className="font-medium">{animalSavingsTotals.animalBreakdown.dairy_cows}</span>
                      </div>
                    )}
                    {animalSavingsTotals.animalBreakdown.hens > 0 && (
                      <div className="flex justify-between" data-testid="text-hens-saved">
                        <span>🥚 Poules pondeuses:</span>
                        <span className="font-medium">{animalSavingsTotals.animalBreakdown.hens}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Comparison Details */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h5 className="font-medium text-foreground flex items-center gap-2">
                  <span className="w-3 h-3 bg-red-500 rounded-full"></span>
                  Version Omnivore (totale)
                </h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">CO₂:</span>
                    <span className="font-medium">{climateImpactTotals.originalTotals.co2.toFixed(2)} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Eau:</span>
                    <span className="font-medium">{climateImpactTotals.originalTotals.water.toFixed(0)} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Terre:</span>
                    <span className="font-medium">{climateImpactTotals.originalTotals.land.toFixed(2)} m²</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h5 className="font-medium text-foreground flex items-center gap-2">
                  <span className="w-3 h-3 bg-green-500 rounded-full"></span>
                  Version Végane (totale)
                </h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">CO₂:</span>
                    <span className="font-medium">{climateImpactTotals.veganTotals.co2.toFixed(2)} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Eau:</span>
                    <span className="font-medium">{climateImpactTotals.veganTotals.water.toFixed(0)} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Terre:</span>
                    <span className="font-medium">{climateImpactTotals.veganTotals.land.toFixed(2)} m²</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Global Supplement Recommendations */}
      <div className="mt-8 pt-6 border-t border-border">
        <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
          <h5 className="font-semibold text-foreground mb-2 flex items-center gap-1">
            <Heart className="w-4 h-4 text-accent" />
            Compléments pour Vos Habitudes Alimentaires
          </h5>
          <p className="text-sm text-muted-foreground mb-3">
            Analyse de {favorites.length} recettes favorites • Recommandations personnalisées :
          </p>
          
          {/* Critical supplements */}
          <div className="space-y-3 mb-4">
            <div className="text-xs font-medium text-red-600 dark:text-red-400">INDISPENSABLES</div>
            {recommendedSupplements
              .filter(supplement => supplement.priority === "critical")
              .map((supplement, index) => (
                <div key={index} className="bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800/30 rounded p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-red-700 dark:text-red-300 text-sm font-medium">
                      {supplement.name}
                    </div>
                    <a
                      href={supplement.amazon_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-2 py-1 bg-orange-600 hover:bg-orange-700 text-white text-xs font-medium rounded transition-colors"
                      data-testid={`amazon-link-${index}`}
                    >
                      <ExternalLink className="w-3 h-3" />
                      Voir sur Amazon
                    </a>
                  </div>
                  <div className="text-xs text-red-600 dark:text-red-400">{supplement.reason}</div>
                </div>
              ))}
          </div>

          {/* High priority deficiencies */}
          {recommendedSupplements.some(s => s.priority === "high") && (
            <div className="space-y-3 mb-4">
              <div className="text-xs font-medium text-orange-600 dark:text-orange-400">CARENCES DÉTECTÉES</div>
              {recommendedSupplements
                .filter(supplement => supplement.priority === "high")
                .map((supplement, index) => (
                  <div key={index} className="bg-orange-50 dark:bg-orange-900/10 border border-orange-200 dark:border-orange-800/30 rounded p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-orange-700 dark:text-orange-300 text-sm font-medium">
                        {supplement.name}
                      </div>
                      <a
                        href={supplement.amazon_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2 py-1 bg-orange-600 hover:bg-orange-700 text-white text-xs font-medium rounded transition-colors"
                        data-testid={`amazon-link-deficiency-${index}`}
                      >
                        <ExternalLink className="w-3 h-3" />
                        Voir sur Amazon
                      </a>
                    </div>
                    <div className="text-xs text-orange-600 dark:text-orange-400">{supplement.reason}</div>
                  </div>
                ))}
            </div>
          )}

        </div>
      </div>
      </CardContent>
    </Card>
  );
}