import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Star } from "lucide-react";
import { type RecipeConversionResponse } from "@shared/schema";

interface AnimalSavingsProps {
  animalSavings: RecipeConversionResponse['animalSavings'];
}

export default function AnimalSavings({ animalSavings }: AnimalSavingsProps) {
  if (!animalSavings || animalSavings.totalAnimals <= 0) {
    return null;
  }

  return (
    <Card data-variant="elevated" className="mb-12">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <Heart className="w-6 h-6 text-red-500" />
          <span>Animaux Sauvés</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 md:p-6 lg:p-8">
        <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-950/20 rounded-lg p-4 md:p-6 space-y-4 md:space-y-6">
          {/* Summary Stats */}
          <div className="grid grid-cols-2 gap-4 md:gap-6">
            <div className="text-center">
              <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-green-600 dark:text-green-400 mb-2" data-testid="text-animals-saved">
                {animalSavings.totalAnimals < 0.1 && animalSavings.totalAnimals > 0 
                  ? "< 0.1" 
                  : Math.round(animalSavings.totalAnimals * 100) / 100}
              </div>
              <div className="text-sm md:text-base text-muted-foreground">animaux sauvés</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2" data-testid="text-life-years-saved">
                {animalSavings.lifeYearsSaved < 0.1 && animalSavings.lifeYearsSaved > 0 
                  ? "< 0.1" 
                  : Math.round(animalSavings.lifeYearsSaved * 100) / 100}
              </div>
              <div className="text-sm md:text-base text-muted-foreground">années de vie sauvées</div>
            </div>
          </div>

          {/* Animal Breakdown */}
          {animalSavings.animalBreakdown && (
            <div className="space-y-3 md:space-y-4">
              <div className="text-sm md:text-base font-medium text-foreground mb-2">Détail par animal :</div>
              <div className="grid grid-cols-2 gap-2 md:gap-3 text-xs md:text-sm">
                {animalSavings.animalBreakdown.cows > 0 && (
                  <div className="flex justify-between p-2 bg-white dark:bg-gray-800 rounded" data-testid="breakdown-cows">
                    <span>🐄 Vaches :</span>
                    <span className="font-medium">
                      {animalSavings.animalBreakdown.cows < 0.1 
                        ? "< 0.1" 
                        : Math.round(animalSavings.animalBreakdown.cows * 100) / 100}
                    </span>
                  </div>
                )}
                {animalSavings.animalBreakdown.pigs > 0 && (
                  <div className="flex justify-between p-2 bg-white dark:bg-gray-800 rounded" data-testid="breakdown-pigs">
                    <span>🐷 Cochons :</span>
                    <span className="font-medium">
                      {animalSavings.animalBreakdown.pigs < 0.1 
                        ? "< 0.1" 
                        : Math.round(animalSavings.animalBreakdown.pigs * 100) / 100}
                    </span>
                  </div>
                )}
                {animalSavings.animalBreakdown.chickens > 0 && (
                  <div className="flex justify-between p-2 bg-white dark:bg-gray-800 rounded" data-testid="breakdown-chickens">
                    <span>🐔 Poulets :</span>
                    <span className="font-medium">
                      {animalSavings.animalBreakdown.chickens < 0.1 
                        ? "< 0.1" 
                        : Math.round(animalSavings.animalBreakdown.chickens * 100) / 100}
                    </span>
                  </div>
                )}
                {animalSavings.animalBreakdown.fish > 0 && (
                  <div className="flex justify-between p-2 bg-white dark:bg-gray-800 rounded" data-testid="breakdown-fish">
                    <span>🐟 Poissons :</span>
                    <span className="font-medium">
                      {animalSavings.animalBreakdown.fish < 0.1 
                        ? "< 0.1" 
                        : Math.round(animalSavings.animalBreakdown.fish * 100) / 100}
                    </span>
                  </div>
                )}
                {animalSavings.animalBreakdown.dairy_cows > 0 && (
                  <div className="flex justify-between p-2 bg-white dark:bg-gray-800 rounded" data-testid="breakdown-dairy-cows">
                    <span>🥛 Vaches laitières :</span>
                    <span className="font-medium">
                      {animalSavings.animalBreakdown.dairy_cows < 0.1 
                        ? "< 0.1" 
                        : Math.round(animalSavings.animalBreakdown.dairy_cows * 100) / 100}
                    </span>
                  </div>
                )}
                {animalSavings.animalBreakdown.hens > 0 && (
                  <div className="flex justify-between p-2 bg-white dark:bg-gray-800 rounded" data-testid="breakdown-hens">
                    <span>🥚 Poules :</span>
                    <span className="font-medium">
                      {animalSavings.animalBreakdown.hens < 0.1 
                        ? "< 0.1" 
                        : Math.round(animalSavings.animalBreakdown.hens * 100) / 100}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Call to action */}
          <div className="text-center p-3 md:p-4 bg-white/50 dark:bg-gray-800/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 text-sm md:text-base text-muted-foreground">
              <Star className="w-4 h-4 text-yellow-500" />
              <span>
                En choisissant cette version végane, vous contribuez à sauver la vie de ces animaux !
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}