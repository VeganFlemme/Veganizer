import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { type RecipeConversionResponse } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

interface SearchSectionProps {
  onConversionResult: (result: RecipeConversionResponse) => void;
  onConversionStart?: () => void;
  onConversionError?: () => void;
}

interface SuggestionsResponse {
  success: boolean;
  data: string[];
}

export default function SearchSection({ 
  onConversionResult, 
  onConversionStart, 
  onConversionError 
}: SearchSectionProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: suggestionsData, isLoading: suggestionsLoading } = useQuery<SuggestionsResponse>({
    queryKey: [`/api/suggestions?q=${encodeURIComponent(searchQuery)}`],
    enabled: searchQuery.length > 2,
    staleTime: 5 * 60 * 1000, // Cache suggestions for 5 minutes
    gcTime: 10 * 60 * 1000, // Keep in cache for 10 minutes
  });

  const suggestions = suggestionsData?.success ? suggestionsData.data : [];

  const convertMutation = useMutation({
    mutationFn: async (recipeName: string) => {
      onConversionStart?.();
      const response = await apiRequest("POST", "/api/recipes/convert", { recipeName });
      return response.json();
    },
    onSuccess: (data: RecipeConversionResponse) => {
      onConversionResult(data);
      setShowSuggestions(false);
      // Scroll to results
      setTimeout(() => {
        const resultsElement = document.getElementById("comparison-section");
        if (resultsElement) {
          resultsElement.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }, 100);
    },
    onError: () => {
      onConversionError?.();
      toast({
        title: "Erreur",
        description: "Impossible de convertir la recette. Veuillez réessayer.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    
    // Only allow predefined recipes from database suggestions
    if (suggestions.includes(searchQuery)) {
      convertMutation.mutate(searchQuery);
    } else {
      toast({
        title: "Recette non trouvée",
        description: "Veuillez sélectionner une recette dans la liste des suggestions.",
        variant: "destructive",
      });
    }
  };

  const handleSuggestionClick = (suggestionName: string) => {
    setSearchQuery(suggestionName);
    setShowSuggestions(false);
    convertMutation.mutate(suggestionName);
  };

  const handleInputChange = (value: string) => {
    setSearchQuery(value);
    setShowSuggestions(value.length > 2);
    setActiveIndex(-1);
  };

  const handleKeyDown = useCallback((event: React.KeyboardEvent) => {
    if (!showSuggestions || suggestions.length === 0) {
      if (event.key === "Enter") {
        // Only allow Enter if the typed text exactly matches a known recipe
        if (suggestions.includes(searchQuery)) {
          handleSearch();
        } else {
          toast({
            title: "Recette non trouvée",
            description: "Veuillez sélectionner une recette dans la liste des suggestions.",
            variant: "destructive",
          });
        }
      }
      return;
    }

    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        setActiveIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : 0
        );
        break;
      case "ArrowUp":
        event.preventDefault();
        setActiveIndex(prev => 
          prev > 0 ? prev - 1 : suggestions.length - 1
        );
        break;
      case "Enter":
        event.preventDefault();
        if (activeIndex >= 0 && activeIndex < suggestions.length) {
          handleSuggestionClick(suggestions[activeIndex]);
        } else {
          // Only allow Enter if the typed text exactly matches a suggestion
          if (suggestions.includes(searchQuery)) {
            handleSearch();
          } else {
            toast({
              title: "Recette non trouvée",
              description: "Veuillez sélectionner une recette dans la liste des suggestions.",
              variant: "destructive",
            });
          }
        }
        break;
      case "Escape":
        event.preventDefault();
        setShowSuggestions(false);
        setActiveIndex(-1);
        inputRef.current?.blur();
        break;
    }
  }, [showSuggestions, suggestions, activeIndex, searchQuery, toast]);

  return (
    <div className="relative py-4 md:py-6 lg:py-8">
      <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8">
        <motion.div 
          className="relative"
          whileHover={{ scale: 1.02 }}
          transition={{ duration: 0.2 }}
        >
          <Card data-variant="glass" className="p-2 md:p-3">
            <div className="grid grid-cols-[1fr,auto] gap-2 md:gap-3">
              <Input
                ref={inputRef}
                type="text"
                placeholder="Tapez votre recette..."
                value={searchQuery}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyDown={handleKeyDown}
                onFocus={() => setShowSuggestions(searchQuery.length > 2)}
                onBlur={() => setTimeout(() => {
                  setShowSuggestions(false);
                  setActiveIndex(-1);
                }, 200)}
                className="px-4 py-3 md:px-6 md:py-4 text-base md:text-lg border-0 bg-transparent focus:ring-0 focus:outline-none placeholder:text-muted-foreground/60 min-h-[48px] md:min-h-[56px]"
                data-testid="input-recipe-search"
              />
              <Button
                onClick={handleSearch}
                disabled={convertMutation.isPending || !searchQuery.trim() || !suggestions.includes(searchQuery)}
                className="px-4 py-3 md:px-6 md:py-4 text-sm md:text-base bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-semibold shadow-md hover:shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed min-h-[48px] md:min-h-[56px] flex items-center justify-center"
                data-testid="button-convert-recipe"
              >
                {convertMutation.isPending ? (
                  <>
                    <motion.div
                      className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    />
                    Conversion...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Végétaliser
                  </>
                )}
              </Button>
            </div>
            <div className="text-xs text-muted-foreground mt-2 px-1">
              Entrez le nom d'une recette pour la convertir en version végane
            </div>
          </Card>
        </motion.div>
        
        {showSuggestions && suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            <Card data-variant="glass" className="absolute top-full mt-2 w-full shadow-2xl z-[60] max-h-[40vh] md:max-h-[60vh] overflow-y-auto">
              {suggestions.map((suggestionName, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`px-3 py-3 md:px-6 md:py-4 cursor-pointer border-b border-border/50 last:border-b-0 transition-colors min-h-[40px] md:min-h-[48px] flex items-center ${
                    index === activeIndex 
                      ? 'bg-primary/10 text-primary' 
                      : 'hover:bg-primary/5'
                  }`}
                  onClick={() => handleSuggestionClick(suggestionName)}
                  onMouseEnter={() => setActiveIndex(index)}
                  onMouseLeave={() => setActiveIndex(-1)}
                  data-testid={`suggestion-${index}`}
                >
                  <span className="text-xs md:text-sm font-medium">{suggestionName}</span>
                </motion.div>
              ))}
            </Card>
          </motion.div>
        )}

        {showSuggestions && suggestions.length === 0 && searchQuery.length > 2 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          >
            <Card data-variant="glass" className="absolute top-full mt-2 w-full shadow-lg z-[60]">
              <div className="px-3 py-3 md:px-6 md:py-4 text-center text-muted-foreground">
                <Sparkles className="w-5 h-5 mx-auto mb-2 text-accent" />
                <div className="text-xs md:text-sm font-medium">Aucune recette trouvée</div>
              </div>
            </Card>
          </motion.div>
        )}
        
        {convertMutation.isPending && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 md:mt-6"
          >
            <Card 
              data-variant="glass" 
              className="flex items-center justify-center space-x-2 md:space-x-3 p-4 md:p-6" 
              data-testid="loading-conversion"
            >
              <motion.div
                className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              />
              <span className="text-sm text-foreground font-medium">
                Conversion en cours... Analyse des ingrédients
              </span>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}