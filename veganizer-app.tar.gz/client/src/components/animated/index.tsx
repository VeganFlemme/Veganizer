/**
 * Animated Components for Premium UX
 * Reusable Framer Motion components with built-in animations
 */

import { motion, HTMLMotionProps, AnimatePresence, useReducedMotion } from 'framer-motion';
import { forwardRef, ReactNode, useEffect, useRef } from 'react';
import {
  pageTransition,
  cardHover,
  fadeInUp,
  staggerContainer,
  staggerItem,
  buttonMotion,
  modalMotion,
  heroMotion,
  badgePulse,
  chartMotion,
  createViewportAnimation,
  reducedMotion,
} from '@/lib/animations';

// Page wrapper with entrance animation
interface AnimatedPageProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
}

export const AnimatedPage = forwardRef<HTMLDivElement, AnimatedPageProps>(
  ({ children, className = '', ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={className}
        variants={pageTransition}
        initial="initial"
        animate="animate"
        exit="exit"
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

AnimatedPage.displayName = 'AnimatedPage';

// Animated card with hover effects
interface AnimatedCardProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
  hoverEnabled?: boolean;
}

export const AnimatedCard = forwardRef<HTMLDivElement, AnimatedCardProps>(
  ({ children, className = '', hoverEnabled = true, ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={`${className} cursor-pointer`}
        variants={hoverEnabled ? cardHover : undefined}
        initial="rest"
        whileHover={hoverEnabled ? "hover" : undefined}
        whileTap={hoverEnabled ? "tap" : undefined}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

AnimatedCard.displayName = 'AnimatedCard';

// Animated button with interaction states
interface AnimatedButtonProps extends HTMLMotionProps<'button'> {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
}

export const AnimatedButton = forwardRef<HTMLButtonElement, AnimatedButtonProps>(
  ({ children, className = '', variant = 'primary', ...props }, ref) => {
    return (
      <motion.button
        ref={ref}
        className={className}
        variants={buttonMotion}
        initial="rest"
        whileHover="hover"
        whileTap="tap"
        {...props}
      >
        {children}
      </motion.button>
    );
  }
);

AnimatedButton.displayName = 'AnimatedButton';

// Fade in section with viewport trigger
interface FadeInSectionProps extends HTMLMotionProps<'section'> {
  children: ReactNode;
  threshold?: number;
  delay?: number;
}

export const FadeInSection = forwardRef<HTMLElement, FadeInSectionProps>(
  ({ children, className = '', threshold = 0.1, delay = 0, ...props }, ref) => {
    return (
      <motion.section
        ref={ref}
        className={className}
        variants={fadeInUp}
        {...createViewportAnimation(threshold)}
        transition={{ delay }}
        {...props}
      >
        {children}
      </motion.section>
    );
  }
);

FadeInSection.displayName = 'FadeInSection';

// Staggered list container with reduced motion support
interface StaggeredListProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
}

export const StaggeredList = forwardRef<HTMLDivElement, StaggeredListProps>(
  ({ children, className = '', ...props }, ref) => {
    const shouldReduceMotion = useReducedMotion();

    return (
      <motion.div
        ref={ref}
        className={className}
        variants={shouldReduceMotion ? reducedMotion : staggerContainer}
        initial={shouldReduceMotion ? "initial" : "hidden"}
        animate={shouldReduceMotion ? "animate" : "visible"}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

StaggeredList.displayName = 'StaggeredList';

// Staggered list item
interface StaggeredItemProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
}

export const StaggeredItem = forwardRef<HTMLDivElement, StaggeredItemProps>(
  ({ children, className = '', ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={className}
        variants={staggerItem}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

StaggeredItem.displayName = 'StaggeredItem';

// Animated modal/dialog with proper exit animations
interface AnimatedModalProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
  isOpen: boolean;
}

export const AnimatedModal = forwardRef<HTMLDivElement, AnimatedModalProps>(
  ({ children, className = '', isOpen, ...props }, ref) => {
    const internalRef = useRef<HTMLDivElement>(null);
    const modalRef = ref || internalRef;

    useEffect(() => {
      if (isOpen && 'current' in modalRef && modalRef.current) {
        modalRef.current.focus();
      }
    }, [isOpen, modalRef]);

    return (
      <AnimatePresence>
        {isOpen && (
          <motion.div
            ref={modalRef}
            className={className}
            variants={modalMotion}
            initial="hidden"
            animate="visible"
            exit="exit"
            role="dialog"
            aria-modal="true"
            tabIndex={-1}
            {...props}
          >
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    );
  }
);

AnimatedModal.displayName = 'AnimatedModal';

// Hero section with entrance animation
interface AnimatedHeroProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
}

export const AnimatedHero = forwardRef<HTMLDivElement, AnimatedHeroProps>(
  ({ children, className = '', ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={className}
        variants={heroMotion}
        initial="hidden"
        animate="visible"
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

AnimatedHero.displayName = 'AnimatedHero';

// Animated badge with pulse effect and reduced motion support
interface AnimatedBadgeProps extends HTMLMotionProps<'span'> {
  children: ReactNode;
  pulse?: boolean;
}

export const AnimatedBadge = forwardRef<HTMLSpanElement, AnimatedBadgeProps>(
  ({ children, className = '', pulse = false, ...props }, ref) => {
    const shouldReduceMotion = useReducedMotion();

    return (
      <motion.span
        ref={ref}
        className={className}
        variants={pulse && !shouldReduceMotion ? badgePulse : undefined}
        initial={pulse && !shouldReduceMotion ? "rest" : undefined}
        animate={pulse && !shouldReduceMotion ? "pulse" : undefined}
        {...props}
      >
        {children}
      </motion.span>
    );
  }
);

AnimatedBadge.displayName = 'AnimatedBadge';

// Animated chart container
interface AnimatedChartProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
}

export const AnimatedChart = forwardRef<HTMLDivElement, AnimatedChartProps>(
  ({ children, className = '', ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={className}
        variants={chartMotion}
        {...createViewportAnimation(0.3)}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

AnimatedChart.displayName = 'AnimatedChart';

// Loading spinner with reduced motion support
interface AnimatedSpinnerProps extends HTMLMotionProps<'div'> {
  size?: 'sm' | 'md' | 'lg';
}

export const AnimatedSpinner = forwardRef<HTMLDivElement, AnimatedSpinnerProps>(
  ({ className = '', size = 'md', ...props }, ref) => {
    const shouldReduceMotion = useReducedMotion();
    const sizeClasses = {
      sm: 'w-4 h-4',
      md: 'w-6 h-6',
      lg: 'w-8 h-8',
    };

    return (
      <motion.div
        ref={ref}
        className={`${sizeClasses[size]} border-2 border-gray-300 rounded-full ${className}`}
        style={{
          borderTopColor: 'hsl(var(--primary))',
        }}
        animate={shouldReduceMotion ? {} : { rotate: 360 }}
        transition={{
          duration: 1,
          repeat: shouldReduceMotion ? 0 : Infinity,
          ease: 'linear',
        }}
        {...props}
      />
    );
  }
);

AnimatedSpinner.displayName = 'AnimatedSpinner';

// Viewport-triggered animation wrapper
interface InViewProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
  threshold?: number;
  triggerOnce?: boolean;
}

export const InView = forwardRef<HTMLDivElement, InViewProps>(
  ({ children, className = '', threshold = 0.1, triggerOnce = true, ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={className}
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: triggerOnce, amount: threshold }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

InView.displayName = 'InView';

// Text typing animation with accessibility support
interface TypewriterTextProps extends HTMLMotionProps<'div'> {
  text: string;
  delay?: number;
  speed?: number;
}

export const TypewriterText = forwardRef<HTMLDivElement, TypewriterTextProps>(
  ({ text, className = '', delay = 0, speed = 0.05, ...props }, ref) => {
    const shouldReduceMotion = useReducedMotion();

    if (shouldReduceMotion) {
      return (
        <motion.div
          ref={ref}
          className={className}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: delay * 0.1 }}
          aria-label={text}
          {...props}
        >
          {text}
        </motion.div>
      );
    }

    return (
      <motion.div
        ref={ref}
        className={className}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay }}
        aria-label={text}
        aria-live="polite"
        {...props}
      >
        {text.split('').map((char, index) => (
          <motion.span
            key={index}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{
              delay: delay + index * speed,
              duration: 0.1,
            }}
          >
            {char === ' ' ? '\u00A0' : char}
          </motion.span>
        ))}
      </motion.div>
    );
  }
);

TypewriterText.displayName = 'TypewriterText';

// Skeleton Loading Components
interface SkeletonProps {
  className?: string;
}

export const SkeletonLine = ({ className = '' }: SkeletonProps) => (
  <div className={`skeleton h-4 bg-muted rounded ${className}`} aria-hidden="true" />
);

export const SkeletonCard = ({ className = '' }: SkeletonProps) => (
  <div className={`skeleton h-32 bg-muted rounded-lg ${className}`} aria-hidden="true" />
);

export const SkeletonText = ({ className = '' }: SkeletonProps) => (
  <div className={`skeleton h-6 bg-muted rounded ${className}`} aria-hidden="true" />
);

export const SkeletonButton = ({ className = '' }: SkeletonProps) => (
  <div className={`skeleton h-10 w-24 bg-muted rounded-md ${className}`} aria-hidden="true" />
);

// Recipe Comparison Skeleton
export const RecipeComparisonSkeleton = () => {
  const shouldReduceMotion = useReducedMotion();
  
  return (
    <motion.section 
      id="results-section" 
      className="grid lg:grid-cols-2 gap-8 mb-12"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.3 }}
      data-testid="recipe-comparison-skeleton"
      role="status"
      aria-label="Chargement des résultats de conversion"
    >
      {/* Original Recipe Skeleton */}
      <div className="bg-card border rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between mb-4">
          <SkeletonText className="w-48 h-8" />
          <div className="skeleton h-6 w-16 bg-muted rounded-full" aria-hidden="true" />
        </div>
        <div className="space-y-2">
          <SkeletonLine className="w-full" />
          <SkeletonLine className="w-3/4" />
          <SkeletonLine className="w-5/6" />
        </div>
        <div className="flex gap-4 mt-4">
          <div className="skeleton h-8 w-20 bg-muted rounded-full" aria-hidden="true" />
          <div className="skeleton h-8 w-20 bg-muted rounded-full" aria-hidden="true" />
          <div className="skeleton h-8 w-20 bg-muted rounded-full" aria-hidden="true" />
        </div>
      </div>
      
      {/* Vegan Recipe Skeleton */}
      <div className="bg-card border rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between mb-4">
          <SkeletonText className="w-48 h-8" />
          <div className="skeleton h-6 w-16 bg-muted rounded-full" aria-hidden="true" />
        </div>
        <div className="space-y-2">
          <SkeletonLine className="w-full" />
          <SkeletonLine className="w-4/5" />
          <SkeletonLine className="w-3/4" />
        </div>
        <div className="flex gap-4 mt-4">
          <div className="skeleton h-8 w-20 bg-muted rounded-full" aria-hidden="true" />
          <div className="skeleton h-8 w-20 bg-muted rounded-full" aria-hidden="true" />
          <div className="skeleton h-8 w-20 bg-muted rounded-full" aria-hidden="true" />
        </div>
        <div className="pt-4 border-t">
          <SkeletonButton className="w-full h-10" />
        </div>
      </div>
    </motion.section>
  );
};

// Nutrition Analysis Skeleton
export const NutritionAnalysisSkeleton = () => {
  const shouldReduceMotion = useReducedMotion();
  
  return (
    <motion.section 
      className="mb-12"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.4, delay: 0.1 }}
      data-testid="nutrition-analysis-skeleton"
      role="status"
      aria-label="Chargement de l'analyse nutritionnelle"
    >
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <SkeletonText className="w-64 h-8" />
          <div className="skeleton h-6 w-20 bg-muted rounded-full" aria-hidden="true" />
        </div>
        
        {/* Stats Grid Skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-muted/20 rounded-lg p-4 space-y-2">
              <div className="skeleton h-6 w-24 bg-muted rounded" aria-hidden="true" />
              <div className="skeleton h-8 w-16 bg-muted rounded" aria-hidden="true" />
              <div className="skeleton h-4 w-20 bg-muted rounded" aria-hidden="true" />
            </div>
          ))}
        </div>
        
        {/* Chart Skeleton */}
        <div className="bg-muted/10 rounded-lg p-4">
          <div className="skeleton h-64 bg-muted rounded" aria-hidden="true" />
        </div>
      </div>
    </motion.section>
  );
};

// Empty States Components
interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
  className?: string;
}

export const EmptyState = ({ 
  icon, 
  title, 
  description, 
  action, 
  className = '' 
}: EmptyStateProps) => {
  const shouldReduceMotion = useReducedMotion();
  
  return (
    <motion.div 
      className={`text-center py-12 px-4 ${className}`}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.3 }}
      data-testid="empty-state"
      role="status"
      aria-live="polite"
    >
      {icon && (
        <motion.div 
          className="mb-4 flex justify-center text-muted-foreground"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.3, delay: 0.1 }}
          aria-hidden="true"
        >
          {icon}
        </motion.div>
      )}
      <motion.h3 
        className="text-lg font-semibold text-foreground mb-2"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.3, delay: 0.2 }}
      >
        {title}
      </motion.h3>
      <motion.p 
        className="text-muted-foreground mb-6 max-w-md mx-auto"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.3, delay: 0.3 }}
      >
        {description}
      </motion.p>
      {action && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={shouldReduceMotion ? { duration: 0.01 } : { duration: 0.3, delay: 0.4 }}
        >
          {action}
        </motion.div>
      )}
    </motion.div>
  );
};

// Export motion for direct use when needed
export { motion } from 'framer-motion';