import logoPath from "@assets/logo2.svg";
import { Leaf, BarChart3, Globe, ShoppingCart, Menu, Heart, User, LogOut, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

interface HeaderProps {
  canNavigate?: boolean;
  hasSavedMeals?: boolean;
}

export default function Header({ canNavigate = false, hasSavedMeals = false }: HeaderProps) {
  const { user, logout } = useAuth();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
      });
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  const navigationItems = [
    { id: 'comparison-section', label: 'Comparaison', icon: Leaf },
    { id: 'nutrition-section', label: 'Nutrition', icon: BarChart3 },
    { id: 'climate-section', label: 'Environnement', icon: Globe },
    { id: 'shopping-section', label: 'Liste de Courses', icon: ShoppingCart },
  ];

  // Filter items based on what's actually present in the DOM
  const getAvailableItems = () => {
    return navigationItems.filter(item => document.getElementById(item.id));
  };

  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      {/* Skip to content link for keyboard navigation */}
      <a href="#main-content" className="skip-link" data-testid="skip-to-content">
        Aller au contenu principal
      </a>
      <div className="container mx-auto px-4 md:px-6 lg:px-8 py-4 md:py-5 lg:py-6 max-w-7xl">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3 md:space-x-4 p-2 -m-2" data-testid="logo-home">
            <img 
              src={logoPath} 
              alt="Veganizer Logo" 
              className="w-12 h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 xl:w-18 xl:h-18 rounded-lg object-contain"
              onError={(e) => {
                console.warn('Logo failed to load, using fallback');
                e.currentTarget.src = '/logo.png'; // Fallback logo
              }}
              loading="eager"
            />
            <h1 className="text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-foreground">
              Veganizer
            </h1>
          </div>

          {/* Right side with user info and menus */}
          <div className="flex items-center gap-2 md:gap-4">
            {/* User Avatar and Name */}
            {user && (
              <div className="flex items-center gap-2 md:gap-3">
                <Avatar className="w-8 h-8 md:w-10 md:h-10">
                  <AvatarFallback className="bg-green-600 text-white text-sm md:text-base">
                    {user.firstName?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden md:inline text-sm font-medium text-foreground" data-testid="text-user-name">
                  {user.firstName || user.email}
                </span>
              </div>
            )}

            {/* Navigation Menu - Only visible when canNavigate */}
            {canNavigate && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="gap-2"
                    data-testid="button-menu-sections"
                  >
                    <Menu className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {getAvailableItems().map((item) => {
                    const Icon = item.icon;
                    return (
                      <DropdownMenuItem
                        key={item.id}
                        onClick={() => scrollToSection(item.id)}
                        className="cursor-pointer"
                        data-testid={`menu-${item.id}`}
                      >
                        <Icon className="w-4 h-4 mr-2" />
                        {item.label}
                      </DropdownMenuItem>
                    );
                  })}
                  
                  
                  {user && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/plan-alimentaire" className="cursor-pointer" data-testid="menu-plan-alimentaire">
                          <Calendar className="w-4 h-4 mr-2" />
                          Mon Plan Alimentaire
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  
                  {user && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={handleLogout}
                        className="cursor-pointer text-destructive focus:text-destructive"
                        data-testid="menu-logout"
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        Se déconnecter
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Logout button when no navigation menu visible */}
            {!canNavigate && user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="gap-2"
                    data-testid="button-user-menu"
                  >
                    <User className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem 
                    onClick={handleLogout}
                    className="cursor-pointer text-destructive focus:text-destructive"
                    data-testid="menu-logout-simple"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Se déconnecter
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
