import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, AlertTriangle, Activity } from "lucide-react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

interface NutritionAnalysisProps {
  nutritionComparison: {
    original: {
      calories: number;
      proteins: number;
      carbs: number;
      fats: number;
      fiber: number;
      calcium: number;
      iron: number;
      zinc: number;
    };
    vegan: {
      calories: number;
      proteins: number;
      carbs: number;
      fats: number;
      fiber: number;
      calcium: number;
      iron: number;
      zinc: number;
    };
  };
}

export default function NutritionAnalysis({ nutritionComparison }: NutritionAnalysisProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const [isMobile, setIsMobile] = useState(false);

  // Detect mobile screen size
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    if (!chartRef.current) return;

    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstance.current = new Chart(ctx, {
      type: 'radar',
      data: {
        labels: isMobile 
          ? ['Prot.', 'Fibres', 'Ca.', 'Fer', 'Zinc', 'Cal.'] // Shorter labels for mobile
          : ['Protéines', 'Fibres', 'Calcium', 'Fer', 'Zinc', 'Calories'],
        datasets: [{
          label: 'Version Originale',
          data: [
            nutritionComparison.original.proteins,
            nutritionComparison.original.fiber,
            nutritionComparison.original.calcium / 10, // Scale for visualization
            nutritionComparison.original.iron * 10,
            nutritionComparison.original.zinc * 10,
            nutritionComparison.original.calories / 10
          ],
          fill: true,
          backgroundColor: 'rgba(107, 114, 128, 0.1)',
          borderColor: 'rgba(107, 114, 128, 0.8)',
          pointBackgroundColor: 'rgba(107, 114, 128, 0.8)',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: 'rgba(107, 114, 128, 0.8)'
        }, {
          label: 'Version Végane',
          data: [
            nutritionComparison.vegan.proteins,
            nutritionComparison.vegan.fiber,
            nutritionComparison.vegan.calcium / 10,
            nutritionComparison.vegan.iron * 10,
            nutritionComparison.vegan.zinc * 10,
            nutritionComparison.vegan.calories / 10
          ],
          fill: true,
          backgroundColor: 'rgba(56, 69, 82, 0.1)',
          borderColor: 'rgba(56, 69, 82, 0.8)',
          pointBackgroundColor: 'rgba(56, 69, 82, 0.8)',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: 'rgba(56, 69, 82, 0.8)'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        devicePixelRatio: window.devicePixelRatio || 1,
        scales: {
          r: {
            angleLines: {
              display: true,
              lineWidth: isMobile ? 1 : 2
            },
            grid: {
              lineWidth: isMobile ? 1 : 2
            },
            suggestedMin: 0,
            suggestedMax: 100,
            ticks: {
              display: false
            },
            pointLabels: {
              font: {
                size: isMobile ? 10 : 12
              }
            }
          }
        },
        plugins: {
          legend: {
            position: isMobile ? 'top' : 'bottom',
            labels: {
              usePointStyle: true,
              padding: isMobile ? 8 : 16,
              font: {
                size: isMobile ? 10 : 12
              }
            }
          }
        },
        elements: {
          point: {
            radius: isMobile ? 3 : 4
          }
        }
      }
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [nutritionComparison, isMobile]);

  const calculatePercentageChange = (original: number, vegan: number): string => {
    if (original === 0) return "+100%";
    const change = ((vegan - original) / original) * 100;
    return change > 0 ? `+${Math.round(change)}%` : `${Math.round(change)}%`;
  };

  // Intelligent deficiency detection system
  const detectDeficiencies = () => {
    const supplements = [];
    
    // Always include B12 and Omega-3 for vegans
    supplements.push(
      {
        name: "Complément B12 recommandé",
        reason: "Essentiel pour les végans",
        priority: "critical"
      },
      {
        name: "Oméga-3 végane DHA/EPA",
        reason: "Acides gras essentiels",
        priority: "critical"
      }
    );

    // Iron deficiency detection (if vegan iron < 70% of original)
    const ironRatio = nutritionComparison.original.iron > 0 
      ? nutritionComparison.vegan.iron / nutritionComparison.original.iron 
      : 1;
    if (ironRatio < 0.7 || nutritionComparison.vegan.iron < 8) {
      supplements.push({
        name: "Fer bisglycinate hautement absorbable",
        reason: `Fer végane ${Math.round(ironRatio * 100)}% de l'original`,
        priority: "high"
      });
    }

    // Zinc deficiency detection (if vegan zinc < 75% of original)
    const zincRatio = nutritionComparison.original.zinc > 0 
      ? nutritionComparison.vegan.zinc / nutritionComparison.original.zinc 
      : 1;
    if (zincRatio < 0.75 || nutritionComparison.vegan.zinc < 8) {
      supplements.push({
        name: "Zinc bisglycinate optimisé",
        reason: `Zinc végane ${Math.round(zincRatio * 100)}% de l'original`,
        priority: "high"
      });
    }

    // Calcium deficiency detection (if vegan calcium < 80% of original)
    const calciumRatio = nutritionComparison.original.calcium > 0 
      ? nutritionComparison.vegan.calcium / nutritionComparison.original.calcium 
      : 1;
    if (calciumRatio < 0.8 || nutritionComparison.vegan.calcium < 400) {
      supplements.push({
        name: "Calcium + Vitamine D3 végane",
        reason: `Calcium végane ${Math.round(calciumRatio * 100)}% de l'original`,
        priority: "high"
      });
    }


    return supplements;
  };

  const recommendedSupplements = detectDeficiencies();

  return (
    <Card data-variant="elevated" className="mb-12">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-primary" />
          <span>Analyse Nutritionnelle Comparative</span>
          <Badge variant="outline" className="ml-auto">
            Par portion
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 md:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
          {/* Nutrition Chart */}
          <div className="lg:col-span-2">
            <div className="bg-accent/30 rounded-lg p-3 md:p-4 lg:p-6">
              <div 
                className="nutrition-chart w-full relative" 
                style={{ 
                  height: isMobile ? '250px' : '300px',
                  minHeight: isMobile ? '200px' : '250px'
                }}
              >
                <canvas 
                  ref={chartRef} 
                  data-testid="chart-nutrition-radar"
                  className="w-full h-full"
                />
              </div>
            </div>
          </div>
          
          {/* Nutrition Summary */}
          <div className="space-y-4 md:space-y-6">
            <div>
              <h4 className="font-semibold text-foreground mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base">
                <TrendingUp className="w-4 h-4 text-primary" />
                Valeurs nutritionnelles
              </h4>
              <div className="space-y-2 md:space-y-3">
                <Card className="p-3 md:p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium text-sm md:text-base">Calories</span>
                    <div className="text-right">
                      <div className="font-bold text-foreground text-sm md:text-base" data-testid="text-vegan-calories">
                        {nutritionComparison.vegan.calories} kcal
                      </div>
                      <Badge 
                        variant="secondary" 
                        className="text-xs" 
                        data-testid="text-calories-change"
                      >
                        {calculatePercentageChange(nutritionComparison.original.calories, nutritionComparison.vegan.calories)}
                      </Badge>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-3 md:p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium text-sm md:text-base">Protéines</span>
                    <div className="text-right">
                      <div className="font-bold text-foreground text-sm md:text-base" data-testid="text-vegan-proteins">
                        {nutritionComparison.vegan.proteins}g
                      </div>
                      <Badge 
                        variant="secondary" 
                        className="text-xs" 
                        data-testid="text-proteins-change"
                      >
                        {calculatePercentageChange(nutritionComparison.original.proteins, nutritionComparison.vegan.proteins)}
                      </Badge>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-3 md:p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium text-sm md:text-base">Fibres</span>
                    <div className="text-right">
                      <div className="font-bold text-foreground text-sm md:text-base" data-testid="text-vegan-fiber">
                        {nutritionComparison.vegan.fiber}g
                      </div>
                      <Badge 
                        variant="secondary" 
                        className="text-xs" 
                        data-testid="text-fiber-change"
                      >
                        {calculatePercentageChange(nutritionComparison.original.fiber, nutritionComparison.vegan.fiber)}
                      </Badge>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-3 md:p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground font-medium text-sm md:text-base">Graisses</span>
                    <div className="text-right">
                      <div className="font-bold text-foreground text-sm md:text-base" data-testid="text-vegan-fats">
                        {nutritionComparison.vegan.fats}g
                      </div>
                      <Badge 
                        variant="secondary" 
                        className="text-xs" 
                        data-testid="text-fats-change"
                      >
                        {calculatePercentageChange(nutritionComparison.original.fats, nutritionComparison.vegan.fats)}
                      </Badge>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
