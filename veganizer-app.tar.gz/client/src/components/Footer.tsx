import { Leaf } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-muted border-t border-border mt-16">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                <Leaf className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-foreground">Veganizer</span>
            </div>
            <p className="text-muted-foreground text-sm">
              Convertissez facilement vos recettes préférées en versions véganes nutritionnellement équilibrées.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-foreground mb-4">Fonctionnalités</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Conversion automatique</li>
              <li>Analyse nutritionnelle</li>
              <li>Listes de courses</li>
              <li>Base de données Ciqual</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-foreground mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Guide d'utilisation</li>
              <li>Suggestions de recettes</li>
              <li>Contact</li>
              <li>Données nutritionnelles</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border mt-8 pt-6 text-center text-sm text-muted-foreground">
          <p>&copy; 2024 Veganizer. Données nutritionnelles basées sur la table Ciqual 2020.</p>
        </div>
      </div>
    </footer>
  );
}
